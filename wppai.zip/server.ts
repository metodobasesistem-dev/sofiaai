import express from 'express';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

// --- PROJECT ID FIX ---
try {
  const configPath = path.resolve(process.cwd(), 'firebase-applet-config.json');
  if (fs.existsSync(configPath)) {
    const config = JSON.parse(fs.readFileSync(configPath, 'utf8'));
    if (config.projectId) {
      process.env.GOOGLE_CLOUD_PROJECT = config.projectId;
      process.env.GCLOUD_PROJECT = config.projectId;
      console.log(`[Server] Forced Project ID: ${config.projectId}`);
    }
  }
} catch (e) {
  console.error('[Server] Error forcing Project ID:', e);
}
// ----------------------

console.log('[Server] Initializing server.ts VERSION 2.5...');
import { createServer as createViteServer } from 'vite';
import dotenv from 'dotenv';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  console.log('[Server] Starting server initialization...');
  const app = express();
  const PORT = 3000;

  // 0. IMMEDIATE LISTEN (to prevent GFE 404 while initializing)
  const server = app.listen(PORT, '0.0.0.0', () => {
    console.log(`[Server] Listening on port ${PORT} (Early Listen)`);
  });

  // 1. EXTREMELY EARLY ROUTES
  app.get('/api/test-top', (req, res) => {
    console.log('[Server] Top-level test hit');
    res.send('TOP OK VERSION 2.4');
  });

  app.get('/api/health-check', (req, res) => {
    console.log('[Server] Health check hit');
    res.json({ status: 'ok', timestamp: new Date().toISOString(), version: '2.4' });
  });

  // 2. MIDDLEWARE
  app.use(express.json());
  app.use((req, res, next) => {
    console.log(`[Server] Request: ${req.method} ${req.url}`);
    next();
  });

  // 3. DYNAMIC IMPORTS FOR ROUTES/CONTROLLERS (to prevent top-level crashes)
  try {
    console.log('[Server] Loading routes and controllers...');
    const { db, admin } = await import('./src/backend/lib/firebaseAdmin.js');
    console.log('[Server] Firebase Admin loaded');
    if (!db) {
      console.error('[Server] Firestore DB not initialized. API routes will be limited.');
    }
    const { getWhatsAppProvider } = await import('./providers/providerFactory.js');
    console.log('[Server] Provider Factory loaded');
    const { sessionController } = await import('./src/backend/controllers/sessionController.js');
    console.log('[Server] Session Controller loaded');
    const sessionRoutes = (await import('./src/backend/routes/sessionRoutes.js')).default;
    const messageRoutes = (await import('./src/backend/routes/messageRoutes.js')).default;
    console.log('[Server] Routes loaded');
    const OpenAI = (await import('openai')).default;
    console.log('[Server] OpenAI loaded');

    const openai = new OpenAI({
      apiKey: process.env.OPENAI_API_KEY,
    });

    const whatsappProvider = getWhatsAppProvider();
    const processedMessages = new Set<string>();
    const lastResponseTime = new Map<string, number>();

    // Register Session Routes
    app.post('/api/sessions/create', async (req, res) => {
      console.log(`[Server] DIRECT POST /api/sessions/create hit`);
      try {
        await sessionController.createSession(req, res);
      } catch (err: any) {
        console.error('[Server] Error in direct session create:', err);
        res.status(500).json({ error: err.message || 'Internal Server Error' });
      }
    });

    app.use('/api/sessions', sessionRoutes);
    app.use('/api/messages', messageRoutes);

    app.get('/api/test-direct', (req, res) => {
      res.json({ message: 'API is working', dbInitialized: !!db });
    });

    /**
     * WEBHOOK AGNOSTICO: WhatsApp
     * Recebe mensagens de qualquer provedor (UAZAPI, Meta, etc.)
     */
    app.post('/api/webhooks/whatsapp', async (req, res) => {
      console.log(`Webhook received from ${whatsappProvider.name}:`, JSON.stringify(req.body, null, 2));

      // 1. Validar Webhook
      if (!whatsappProvider.verifyWebhook(req)) {
        console.warn('Invalid webhook signature or secret');
        return res.status(401).json({ error: 'Unauthorized' });
      }

      // Responder rápido para o provedor
      res.status(200).json({ status: 'received' });

      try {
        // 2. Parsear Eventos Canônicos
        const events = await whatsappProvider.parseInbound(req);

        for (const event of events) {
          const { uid, from, messageId, text, contactName, timestamp } = event;

          // Deduplicação
          if (processedMessages.has(messageId)) {
            console.log(`Message ${messageId} already processed, skipping.`);
            continue;
          }
          processedMessages.add(messageId);
          // Limpar cache antigo (exemplo simples)
          if (processedMessages.size > 1000) processedMessages.clear();

          if (!uid || !from || !text) continue;

          // 3. Buscar Usuário (Tenant) por UID ou InstanceId
          let userDoc = await db.collection('users').doc(uid).get();
          
          // Se não achou pelo UID (pode ser que o provider mandou o instanceId no campo uid)
          if (!userDoc.exists) {
            const userQuery = await db.collection('users').where('whatsapp_instance_id', '==', uid).limit(1).get();
            if (!userQuery.empty) {
              userDoc = userQuery.docs[0];
            }
          }

          if (!userDoc.exists) {
            console.error(`User ${uid} not found for webhook event`);
            continue;
          }
          
          const actualUid = userDoc.id;
          const userData = userDoc.data()!;

          // 4. Upsert no CRM (Contacts)
          const contactsRef = db.collection('contacts');
          const contactSnapshot = await contactsRef
            .where('userId', '==', actualUid)
            .where('telefone', '==', from)
            .limit(1)
            .get();

          let contactId;
          const pushName = contactName || 'Lead WhatsApp';
          if (contactSnapshot.empty) {
            const newContact = await contactsRef.add({
              userId: actualUid,
              nome: pushName,
              telefone: from,
              status_funil: 'Lead',
              data_criacao: admin.firestore.FieldValue.serverTimestamp(),
            });
            contactId = newContact.id;
          } else {
            contactId = contactSnapshot.docs[0].id;
            if (pushName !== 'Lead WhatsApp' && contactSnapshot.docs[0].data().nome === 'Lead WhatsApp') {
              await contactsRef.doc(contactId).update({ nome: pushName });
            }
          }

          // 5. Upsert na Thread (Conversa)
          const threadId = `${actualUid}_${from.replace(/[^a-zA-Z0-9]/g, '_')}`;
          const threadRef = db.collection('threads').doc(threadId);
          
          await threadRef.set({
            userId: actualUid,
            remoteJid: from,
            contactName: pushName,
            lastMessage: text,
            updatedAt: admin.firestore.FieldValue.serverTimestamp(),
            unreadCount: admin.firestore.FieldValue.increment(1),
            channel: 'whatsapp',
            provider: whatsappProvider.name,
            connectedNumber: event.to || ''
          }, { merge: true });

          // 6. Salvar Mensagem Recebida (Inbound)
          await threadRef.collection('messages').doc(messageId).set({
            userId: actualUid,
            text: text,
            timestamp: admin.firestore.FieldValue.serverTimestamp(),
            direction: 'inbound',
            messageId,
            channel: 'whatsapp',
            provider: whatsappProvider.name
          });

          // 7. Automação IA (Throttling e Lógica)
          if (!db) {
            console.warn('[Server] Skipping AI automation: DB not initialized');
            continue;
          }
          const now = Date.now();
          const lastTime = lastResponseTime.get(threadId) || 0;
          if (now - lastTime < 5000) { // Mínimo 5 segundos entre respostas da IA
            console.log(`Throttling AI response for thread ${threadId}`);
            continue;
          }
          lastResponseTime.set(threadId, now);

          // Buscar Agente Ativo
          const agentsRef = db.collection('agents');
          const agentSnapshot = await agentsRef
            .where('userId', '==', actualUid)
            .where('status_ativo', '==', true)
            .limit(1)
            .get();

          if (agentSnapshot.empty) continue;
          const agentData = agentSnapshot.docs[0].data();

          // Gerar Resposta
          const companyName = userData.nome_empresa || 'Nossa Empresa';
          const systemPrompt = `Você é um assistente virtual da empresa ${companyName}. ${agentData.prompt_base}`;

          const completion = await openai.chat.completions.create({
            model: 'gpt-4o-mini',
            messages: [
              { role: 'system', content: systemPrompt },
              { role: 'user', content: text },
            ],
          });

          const aiResponse = completion.choices[0].message.content;
          if (!aiResponse) continue;

          // Enviar via Provedor
          const { providerMessageId } = await whatsappProvider.sendText({
            uid: actualUid,
            to: from,
            text: aiResponse,
            instanceId: userData.whatsapp_instance_id
          });

          // Salvar Outbound
          const aiMsgId = providerMessageId || `ai-${Date.now()}`;
          await threadRef.collection('messages').doc(aiMsgId).set({
            userId: actualUid,
            text: aiResponse,
            timestamp: admin.firestore.FieldValue.serverTimestamp(),
            direction: 'outbound',
            messageId: aiMsgId,
            channel: 'whatsapp',
            provider: whatsappProvider.name
          });

          await threadRef.update({
            lastMessage: aiResponse,
            updatedAt: admin.firestore.FieldValue.serverTimestamp(),
            unreadCount: 0
          });
        }
      } catch (error) {
        console.error('Error processing whatsapp webhook:', error);
      }
    });

    /**
     * CANAL: Status
     */
    app.get('/api/channels/whatsapp/status', async (req, res) => {
      const authHeader = req.headers.authorization;
      if (!authHeader || !authHeader.startsWith('Bearer ')) return res.status(401).json({ error: 'Unauthorized' });

      try {
        const decodedToken = await admin.auth().verifyIdToken(authHeader.split('Bearer ')[1]);
        const uid = decodedToken.uid;

        const userDoc = await db.collection('users').doc(uid).get();
        const instanceId = userDoc.data()?.whatsapp_instance_id;

        const { status, qrCode } = await whatsappProvider.getConnectionStatus({ uid, instanceId });
        
        await db.collection('users').doc(uid).update({ whatsapp_status: status });

        return res.json({ status, qrCode });
      } catch (error: any) {
        console.error('Error checking whatsapp status:', error.message);
        return res.status(500).json({ error: 'Failed to check status' });
      }
    });

    /**
     * CANAL: Conectar
     */
    app.post('/api/channels/whatsapp/connect', async (req, res) => {
      const authHeader = req.headers.authorization;
      if (!authHeader || !authHeader.startsWith('Bearer ')) return res.status(401).json({ error: 'Unauthorized' });

      try {
        const decodedToken = await admin.auth().verifyIdToken(authHeader.split('Bearer ')[1]);
        const uid = decodedToken.uid;

        // Validação de Configuração
        const missingKeys = [];
        if (!process.env.UAZAPI_API_KEY) missingKeys.push('UAZAPI_API_KEY');
        if (!process.env.UAZAPI_BASE_URL) missingKeys.push('UAZAPI_BASE_URL');

        if (missingKeys.length > 0) {
          console.error(`Missing UAZAPI configuration: ${missingKeys.join(', ')}`);
          return res.status(400).json({ 
            error: `Configuração do WhatsApp pendente. Por favor, configure as seguintes chaves no painel de segredos: ${missingKeys.join(', ')}` 
          });
        }

        const userDoc = await db.collection('users').doc(uid).get();
        let instanceId = userDoc.data()?.whatsapp_instance_id;

        if (!instanceId) {
          instanceId = `wppai-${uid.substring(0, 8)}`;
          await db.collection('users').doc(uid).set({ 
            email: decodedToken.email,
            whatsapp_instance_id: instanceId,
            whatsapp_status: 'disconnected',
            updatedAt: admin.firestore.FieldValue.serverTimestamp()
          }, { merge: true });
        } else if (!userDoc.data()?.email) {
          // Se já existe mas não tem email (migração ou erro anterior)
          await db.collection('users').doc(uid).set({ 
            email: decodedToken.email,
            updatedAt: admin.firestore.FieldValue.serverTimestamp()
          }, { merge: true });
        }

        const { qrCode, status } = await whatsappProvider.connect({ uid, instanceId });

        // Configurar Webhook se estiver conectando
        if (status === 'connecting' || status === 'connected') {
          const baseUrl = process.env.APP_URL || '';
          if (baseUrl) {
            const webhookUrl = `${baseUrl}/api/webhooks/whatsapp`;
            await whatsappProvider.setWebhook({ uid, instanceId, url: webhookUrl });
          } else {
            console.warn('APP_URL not set, skipping webhook configuration');
          }
        }

        await db.collection('users').doc(uid).update({ whatsapp_status: status });

        return res.json({ instanceId, qrCode, status });
      } catch (error: any) {
        console.error('Error connecting whatsapp:', error.message, error.stack);
        return res.status(500).json({ 
          error: error.message || 'Failed to connect to WhatsApp provider' 
        });
      }
    });

    /**
     * CANAL: Desconectar
     */
    app.post('/api/channels/whatsapp/disconnect', async (req, res) => {
      const authHeader = req.headers.authorization;
      if (!authHeader || !authHeader.startsWith('Bearer ')) return res.status(401).json({ error: 'Unauthorized' });

      try {
        const decodedToken = await admin.auth().verifyIdToken(authHeader.split('Bearer ')[1]);
        const uid = decodedToken.uid;

        const userDoc = await db.collection('users').doc(uid).get();
        const instanceId = userDoc.data()?.whatsapp_instance_id;

        await whatsappProvider.disconnect({ uid, instanceId });

        await db.collection('users').doc(uid).update({ whatsapp_status: 'disconnected' });

        return res.json({ success: true });
      } catch (error: any) {
        console.error('Error disconnecting whatsapp:', error.message);
        return res.status(500).json({ error: 'Failed to disconnect' });
      }
    });

    /**
     * CANAL: Enviar Mensagem (Manual pela UI)
     */
    app.post('/api/channels/whatsapp/send', async (req, res) => {
      const authHeader = req.headers.authorization;
      if (!authHeader || !authHeader.startsWith('Bearer ')) return res.status(401).json({ error: 'Unauthorized' });

      const { to, text, threadId } = req.body;
      if (!to || !text) return res.status(400).json({ error: 'Missing to or text' });

      try {
        const decodedToken = await admin.auth().verifyIdToken(authHeader.split('Bearer ')[1]);
        const uid = decodedToken.uid;

        const userDoc = await db.collection('users').doc(uid).get();
        const instanceId = userDoc.data()?.whatsapp_instance_id;

        const { providerMessageId } = await whatsappProvider.sendText({ uid, to, text, instanceId });

        // Salvar no Firestore
        const msgId = providerMessageId || `out-${Date.now()}`;
        const finalThreadId = threadId || `${uid}_${to.replace(/[^a-zA-Z0-9]/g, '_')}`;
        const threadRef = db.collection('threads').doc(finalThreadId);

        await threadRef.collection('messages').doc(msgId).set({
          userId: uid,
          text,
          timestamp: admin.firestore.FieldValue.serverTimestamp(),
          direction: 'outbound',
          messageId: msgId,
          channel: 'whatsapp',
          provider: whatsappProvider.name
        });

        await threadRef.update({
          lastMessage: text,
          updatedAt: admin.firestore.FieldValue.serverTimestamp(),
          unreadCount: 0
        });

        return res.json({ success: true, messageId: msgId });
      } catch (error: any) {
        console.error('Error sending whatsapp message:', error.message);
        return res.status(500).json({ error: 'Failed to send message' });
      }
    });

    // Legacy Alias (Evolution)
    app.post('/api/webhook/evolution', (req, res) => res.redirect(307, '/api/webhooks/whatsapp'));
    app.post('/api/whatsapp/connect', (req, res) => res.redirect(307, '/api/channels/whatsapp/connect'));
    app.get('/api/whatsapp/status', (req, res) => res.redirect(307, '/api/channels/whatsapp/status'));
    app.post('/api/whatsapp/disconnect', (req, res) => res.redirect(307, '/api/channels/whatsapp/disconnect'));

  } catch (err: any) {
    console.error('[Server] Error loading dynamic imports:', err);
  }

  // Catch-all for undefined API routes (Moved to end of API routes)
  app.all('/api/*', (req, res) => {
    console.warn(`[Server] 404 CATCH-ALL hit: ${req.method} ${req.url}`);
    res.status(404).json({ 
      error: 'API route not found', 
      path: req.url,
      method: req.method,
      serverVersion: '2.5'
    });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }
}

startServer().catch(err => {
  console.error('[Server] FATAL ERROR during startServer:', err);
  process.exit(1);
});
