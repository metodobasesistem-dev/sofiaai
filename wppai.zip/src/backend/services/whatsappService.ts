import qrcode from 'qrcode';
import path from 'path';
import { db, admin } from '../lib/firebaseAdmin.js';

interface Session {
  client: any;
  qr?: string;
}

class WhatsAppService {
  private sessions: Map<string, Session> = new Map();
  private initializing: Map<string, Promise<string>> = new Map();
  private Client: any = null;
  private LocalAuth: any = null;

  private async loadClient() {
    if (this.Client) return;
    try {
      console.log('[WhatsAppService] Loading whatsapp-web.js...');
      const pkg = await import('whatsapp-web.js');
      this.Client = pkg.default?.Client || pkg.Client;
      this.LocalAuth = pkg.default?.LocalAuth || pkg.LocalAuth;
      console.log('[WhatsAppService] whatsapp-web.js loaded successfully');
    } catch (e) {
      console.error('[WhatsAppService] Failed to load whatsapp-web.js:', e);
      throw new Error('Failed to load WhatsApp library. Please check server logs.');
    }
  }

  private async updateFirestore(userId: string, data: any) {
    try {
      if (!db) {
        console.warn('[WhatsAppService] Firestore DB not initialized, skipping update');
        return;
      }
      console.log(`[WhatsAppService] Updating Firestore for user ${userId}:`, JSON.stringify(data));
      await db.collection('sessions').doc(userId).set({
        ...data,
        updatedAt: admin.firestore.FieldValue.serverTimestamp()
      }, { merge: true });
    } catch (error) {
      console.error(`[WhatsAppService] Error updating Firestore for user ${userId}:`, error);
    }
  }

  async createSession(userId: string): Promise<string> {
    console.log(`--- [WhatsAppService] createSession start for ${userId} ---`);
    if (!userId) {
      console.error('[WhatsAppService] userId is required');
      throw new Error('userId is required');
    }

    await this.loadClient();

    // Check if session already exists and is connected
    if (this.sessions.has(userId)) {
      const session = this.sessions.get(userId)!;
      try {
        const state = await session.client.getState();
        if (state === 'CONNECTED') {
          console.log(`[WhatsAppService] User ${userId} already connected`);
          await this.updateFirestore(userId, { status: 'connected', qr: null });
          return 'connected';
        }
      } catch (e) {
        console.log(`[WhatsAppService] Existing session for ${userId} is not connected or state check failed`);
      }
      
      if (session.qr) {
        console.log(`[WhatsAppService] Returning existing QR for user ${userId}`);
        return session.qr;
      }
    }

    // Check if already initializing
    if (this.initializing.has(userId)) {
      console.log(`[WhatsAppService] Session for ${userId} is already being initialized`);
      return this.initializing.get(userId)!;
    }

    const initPromise = new Promise<string>((resolve, reject) => {
      let resolved = false;

      console.log(`[WhatsAppService] Creating new client for user ${userId}`);
      
      const client = new this.Client({
        authStrategy: new this.LocalAuth({
          clientId: userId,
          dataPath: path.join(process.cwd(), 'sessions')
        }),
        puppeteer: {
          headless: true,
          args: [
            '--no-sandbox', 
            '--disable-setuid-sandbox',
            '--disable-dev-shm-usage',
            '--disable-accelerated-2d-canvas',
            '--no-first-run',
            '--no-zygote',
            '--single-process',
            '--disable-gpu'
          ]
        }
      });

      client.on('loading_screen', (percent, message) => {
        console.log(`[WhatsAppService] Loading screen for ${userId}: ${percent}% - ${message}`);
      });

      client.on('qr', async (qr) => {
        console.log(`[WhatsAppService] QR Code generated for user ${userId}. Length: ${qr.length}`);
        try {
          const qrDataUrl = await qrcode.toDataURL(qr);
          this.sessions.set(userId, { client, qr: qrDataUrl });
          
          // Update Firestore with QR
          await this.updateFirestore(userId, { qr: qrDataUrl, status: 'waiting' });

          if (!resolved) {
            resolved = true;
            this.initializing.delete(userId);
            resolve(qrDataUrl);
          }
        } catch (err) {
          console.error(`[WhatsAppService] Error generating QR Data URL for ${userId}:`, err);
        }
      });

      client.on('ready', async () => {
        console.log(`[WhatsAppService] Client is READY for user ${userId}`);
        this.sessions.set(userId, { client });
        this.initializing.delete(userId);
        
        // Update Firestore as connected
        await this.updateFirestore(userId, { status: 'connected', qr: null });

        if (!resolved) {
          resolved = true;
          resolve('connected');
        }
      });

      client.on('message', async (msg) => {
        console.log(`New message for user ${userId} from ${msg.from}: ${msg.body}`);
        
        try {
          const contact = await msg.getContact();
          const contactName = contact.pushname || contact.name || msg.from;
          const threadId = `${userId}_${msg.from.replace(/[^a-zA-Z0-9]/g, '')}`;

          // Create/Update thread
          await db.collection('threads').doc(threadId).set({
            userId,
            contactId: msg.from,
            remoteJid: msg.from,
            contactName,
            lastMessage: msg.body,
            updatedAt: admin.firestore.FieldValue.serverTimestamp(),
            unreadCount: admin.firestore.FieldValue.increment(1),
            status: 'human' // Default to human for new messages
          }, { merge: true });

          // Add message to root collection (as requested)
          await db.collection('messages').add({
            userId,
            contact: msg.from,
            message: msg.body,
            fromMe: false,
            timestamp: Date.now()
          });

          // Add message to subcollection (for Inbox UI)
          await db.collection('threads').doc(threadId).collection('messages').add({
            text: msg.body,
            direction: 'inbound',
            timestamp: admin.firestore.FieldValue.serverTimestamp(),
            type: msg.type,
            messageId: msg.id.id
          });

        } catch (error) {
          console.error(`Error saving received message for user ${userId}:`, error);
        }
      });

      client.on('disconnected', async (reason) => {
        console.log(`[WhatsAppService] Client DISCONNECTED for user ${userId}. Reason: ${reason}`);
        this.sessions.delete(userId);
        this.initializing.delete(userId);
        await this.updateFirestore(userId, { status: 'disconnected', qr: null });
      });

      client.on('authenticated', () => {
        console.log(`[WhatsAppService] Client AUTHENTICATED for user ${userId}`);
      });

      client.on('auth_failure', async (msg) => {
        console.error(`Auth failure for user ${userId}:`, msg);
        this.initializing.delete(userId);
        await this.updateFirestore(userId, { status: 'disconnected', qr: null });
        if (!resolved) {
          resolved = true;
          reject(new Error('Authentication failure'));
        }
      });

      console.log(`[WhatsAppService] Calling client.initialize() for user ${userId}...`);
      client.initialize().catch(async (err) => {
        console.error(`[WhatsAppService] Initialization error for ${userId}:`, err);
        this.initializing.delete(userId);
        await this.updateFirestore(userId, { status: 'disconnected', qr: null });
        if (!resolved) {
          resolved = true;
          reject(err);
        }
      });

      // Timeout if QR is not received within 45 seconds
      setTimeout(async () => {
        if (!resolved) {
          resolved = true;
          this.initializing.delete(userId);
          await this.updateFirestore(userId, { status: 'disconnected', qr: null });
          reject(new Error('Timeout waiting for QR code'));
        }
      }, 45000);
    });

    this.initializing.set(userId, initPromise);
    console.log(`[WhatsAppService] Session creation promise stored for user ${userId}`);
    return initPromise;
  }

  async getSessionStatus(userId: string) {
    const session = this.sessions.get(userId);
    if (!session) return 'disconnected';
    try {
      const state = await session.client.getState();
      const status = state === 'CONNECTED' ? 'connected' : 'disconnected';
      await this.updateFirestore(userId, { status });
      return status;
    } catch {
      return 'disconnected';
    }
  }

  async sendMessage(userId: string, to: string, message: string) {
    const session = this.sessions.get(userId);
    if (!session) throw new Error('WhatsApp session not found or not connected');

    try {
      const result = await session.client.sendMessage(to, message);
      const threadId = `${userId}_${to.replace(/[^a-zA-Z0-9]/g, '')}`;

      // Update thread
      await db.collection('threads').doc(threadId).set({
        userId,
        contactId: to,
        remoteJid: to,
        lastMessage: message,
        updatedAt: admin.firestore.FieldValue.serverTimestamp()
      }, { merge: true });

      // Add message to root collection (as requested)
      await db.collection('messages').add({
        userId,
        contact: to,
        message,
        fromMe: true,
        timestamp: Date.now()
      });

      // Add message to subcollection
      await db.collection('threads').doc(threadId).collection('messages').add({
        text: message,
        direction: 'outbound',
        timestamp: admin.firestore.FieldValue.serverTimestamp(),
        type: result.type,
        messageId: result.id.id
      });

      return { success: true, messageId: result.id.id };
    } catch (error) {
      console.error(`Error sending message for user ${userId}:`, error);
      throw error;
    }
  }
}

export const whatsappService = new WhatsAppService();
