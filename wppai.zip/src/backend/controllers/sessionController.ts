import { Request, Response } from 'express';
import { whatsappService } from '../services/whatsappService.js';

class SessionController {
  async createSession(req: Request, res: Response) {
    console.log('--- [SessionController] createSession start (non-blocking) ---');
    console.log('Request body:', JSON.stringify(req.body));
    
    const { userId } = req.body;
    
    if (!userId) {
      console.warn('[SessionController] Missing userId in request body');
      return res.status(400).json({ 
        success: false, 
        error: 'Missing userId' 
      });
    }

    console.log(`[SessionController] Triggering session initialization for userId: ${userId}`);

    try {
      // Start the session in the background. Do NOT await the full initialization.
      // We only await the call to start the process.
      whatsappService.createSession(userId).catch(err => {
        console.error(`[SessionController] Background initialization error for ${userId}:`, err);
      });
      
      console.log(`[SessionController] Session initialization triggered for ${userId}`);
      
      // Return immediately to avoid timeouts and "Unexpected token 'T'" from proxy
      res.json({ 
        success: true, 
        message: "Inicialização do WhatsApp iniciada em segundo plano. O QR Code aparecerá em instantes."
      });
    } catch (error: any) {
      console.error(`[SessionController] Error triggering session for ${userId}:`, error);
      res.status(500).json({ 
        success: false, 
        error: error.message || 'Failed to trigger session' 
      });
    } finally {
      console.log('--- [SessionController] createSession end ---');
    }
  }

  async getStatus(req: Request, res: Response) {
    const { userId } = req.params;
    try {
      const status = await whatsappService.getSessionStatus(userId);
      res.json({ status });
    } catch (error: any) {
      console.error('Error getting status:', error);
      res.status(500).json({ error: error.message || 'Failed to get status' });
    }
  }

  async sendMessage(req: Request, res: Response) {
    const { userId, to, message } = req.body;
    if (!userId || !to || !message) {
      return res.status(400).json({ error: 'Missing userId, to, or message' });
    }

    try {
      const result = await whatsappService.sendMessage(userId, to, message);
      res.json(result);
    } catch (error: any) {
      console.error('Error sending message:', error);
      res.status(500).json({ error: error.message || 'Failed to send message' });
    }
  }
}

export const sessionController = new SessionController();
