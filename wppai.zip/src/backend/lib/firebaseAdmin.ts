import admin from 'firebase-admin';
import { getFirestore } from 'firebase-admin/firestore';
import fs from 'fs';
import path from 'path';

let firebaseConfig: any = {};
try {
  const configPath = path.resolve(process.cwd(), 'firebase-applet-config.json');
  console.log(`[FirebaseAdmin] Reading config from: ${configPath}`);
  if (fs.existsSync(configPath)) {
    const content = fs.readFileSync(configPath, 'utf8');
    firebaseConfig = JSON.parse(content);
    console.log(`[FirebaseAdmin] Config loaded. ProjectId: ${firebaseConfig.projectId}`);
    
    // Force environment variables to match our config
    if (firebaseConfig.projectId) {
      process.env.GOOGLE_CLOUD_PROJECT = firebaseConfig.projectId;
      process.env.GCLOUD_PROJECT = firebaseConfig.projectId;
    }
  } else {
    console.error('[FirebaseAdmin] Config file NOT FOUND at', configPath);
  }
} catch (e) {
  console.error('[FirebaseAdmin] Error reading config:', e);
}

if (admin.apps.length > 0) {
  console.log(`[FirebaseAdmin] Existing apps found: ${admin.apps.length}. Re-initializing...`);
  // Optionally delete existing apps to ensure our config is used
  // for (const app of admin.apps) { await app.delete(); } 
  // But delete is async and we are in a module top-level.
}

if (!admin.apps.length) {
  try {
    admin.initializeApp({
      projectId: firebaseConfig.projectId,
    });
    console.log(`[FirebaseAdmin] Initialized with project: ${firebaseConfig.projectId}`);
  } catch (e) {
    console.error('[FirebaseAdmin] initializeApp failed:', e);
  }
} else {
  const currentProject = admin.app().options.projectId;
  console.log(`[FirebaseAdmin] Using existing app with project: ${currentProject}`);
  if (currentProject !== firebaseConfig.projectId && firebaseConfig.projectId) {
    console.warn(`[FirebaseAdmin] PROJECT ID MISMATCH! Expected ${firebaseConfig.projectId} but got ${currentProject}`);
  }
}

let db: any;
try {
  db = getFirestore(firebaseConfig.firestoreDatabaseId || undefined);
} catch (e) {
  console.error('[FirebaseAdmin] getFirestore failed:', e);
}

export { db, admin };
