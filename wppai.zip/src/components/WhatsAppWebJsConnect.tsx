import React, { useState, useEffect } from 'react';
import { db, auth } from '../firebase';
import { doc, onSnapshot } from 'firebase/firestore';
import { Loader2, CheckCircle2, XCircle, RefreshCw, QrCode } from 'lucide-react';
import { toast } from 'sonner';

export default function WhatsAppWebJsConnect() {
  const [session, setSession] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const user = auth.currentUser;

  useEffect(() => {
    if (!user) return;

    const unsubscribe = onSnapshot(doc(db, 'sessions', user.uid), (doc) => {
      if (doc.exists()) {
        setSession(doc.data());
      }
    });

    return () => unsubscribe();
  }, [user]);

  const handleConnect = async () => {
    if (!user) return;
    setLoading(true);
    try {
      console.log('[WhatsAppConnect] Testing API connectivity...');
      const healthCheck = await fetch('/api/health-check');
      if (!healthCheck.ok) {
        console.warn('[WhatsAppConnect] API health check failed:', healthCheck.status);
      } else {
        console.log('[WhatsAppConnect] API health check successful');
      }

      console.log('[WhatsAppConnect] Calling /api/sessions/create...');
      const response = await fetch('/api/sessions/create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: user.uid }),
      });
      
      console.log('[WhatsAppConnect] Response status:', response.status);

      if (!response.ok) {
        const text = await response.text();
        console.error('[WhatsAppConnect] Error response text:', text);
        try {
          const error = JSON.parse(text);
          throw new Error(error.error || 'Falha ao iniciar sessão');
        } catch (e) {
          throw new Error(`Erro do servidor (HTML): ${text.substring(0, 100)}...`);
        }
      }

      const data = await response.json();
      console.log('[WhatsAppConnect] Success response:', data);
      toast.success(data.message || 'Iniciando conexão...');
    } catch (error: any) {
      console.error('Error connecting:', error);
      toast.error(error.message);
    } finally {
      setLoading(false);
    }
  };

  const testTop = async () => {
    try {
      const response = await fetch('/api/test-top');
      const text = await response.text();
      toast.success(`Top API: ${text}`);
    } catch (err) {
      toast.error(`Erro Top API: ${err instanceof Error ? err.message : String(err)}`);
    }
  };

  const testApi = async () => {
    try {
      const response = await fetch('/api/health-check');
      const data = await response.json();
      toast.success(`API Conectada: ${data.timestamp}`);
    } catch (err) {
      toast.error(`Erro ao conectar na API: ${err instanceof Error ? err.message : String(err)}`);
    }
  };

  return (
    <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-green-100 text-green-600 rounded-lg">
            <QrCode size={24} />
          </div>
          <div>
            <h3 className="text-lg font-bold text-gray-900">WhatsApp Web JS</h3>
            <p className="text-sm text-gray-500">Conexão direta via QR Code</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button 
            onClick={testTop}
            className="text-[10px] text-gray-400 hover:text-gray-600 transition-colors mr-1 border border-gray-200 px-1 rounded"
          >
            Test Top
          </button>
          <button 
            onClick={testApi}
            className="text-[10px] text-gray-400 hover:text-gray-600 transition-colors mr-2 border border-gray-200 px-1 rounded"
          >
            Testar API
          </button>
          {session?.status === 'connected' ? (
            <span className="flex items-center gap-1 px-3 py-1 bg-green-100 text-green-700 rounded-full text-xs font-medium">
              <CheckCircle2 size={14} /> Conectado
            </span>
          ) : session?.status === 'waiting' ? (
            <span className="flex items-center gap-1 px-3 py-1 bg-yellow-100 text-yellow-700 rounded-full text-xs font-medium">
              <RefreshCw size={14} className="animate-spin" /> Aguardando QR
            </span>
          ) : (
            <span className="flex items-center gap-1 px-3 py-1 bg-gray-100 text-gray-700 rounded-full text-xs font-medium">
              <XCircle size={14} /> Desconectado
            </span>
          )}
        </div>
      </div>

      <div className="space-y-4">
        {session?.qr && session.status === 'waiting' && (
          <div className="flex flex-col items-center justify-center p-4 bg-gray-50 rounded-lg border-2 border-dashed border-gray-200">
            <p className="text-sm text-gray-600 mb-4 text-center">
              Escaneie o QR Code abaixo com seu WhatsApp:
            </p>
            <div className="bg-white p-4 rounded-lg shadow-md">
              <img src={session.qr} alt="WhatsApp QR Code" className="w-64 h-64" />
            </div>
            <p className="text-xs text-gray-400 mt-4">
              O QR Code expira em breve. Se não funcionar, clique em "Conectar" novamente.
            </p>
          </div>
        )}

        {session?.status === 'connected' && (
          <div className="p-4 bg-green-50 text-green-800 rounded-lg border border-green-100">
            <p className="text-sm font-medium flex items-center gap-2">
              <CheckCircle2 size={18} /> Seu WhatsApp está conectado e pronto para uso!
            </p>
          </div>
        )}

        <button
          onClick={handleConnect}
          disabled={loading || session?.status === 'connected'}
          className={`w-full py-3 px-4 rounded-lg font-bold flex items-center justify-center gap-2 transition-all ${
            session?.status === 'connected'
              ? 'bg-gray-100 text-gray-400 cursor-not-allowed'
              : 'bg-green-600 text-white hover:bg-green-700 shadow-lg shadow-green-100'
          }`}
        >
          {loading ? (
            <>
              <Loader2 size={20} className="animate-spin" /> Iniciando...
            </>
          ) : session?.status === 'connected' ? (
            'WhatsApp Conectado'
          ) : (
            'Conectar WhatsApp'
          )}
        </button>
      </div>
    </div>
  );
}
