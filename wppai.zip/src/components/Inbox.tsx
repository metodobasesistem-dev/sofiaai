import React, { useState, useEffect, useRef } from 'react';
import { 
  Search, 
  Paperclip, 
  Send, 
  User, 
  Bot, 
  MoreVertical, 
  Phone, 
  Video,
  CheckCheck,
  Loader2,
  MessageCircle
} from 'lucide-react';
import { motion } from 'motion/react';
import { db, auth } from '../firebase';
import { 
  collection, 
  query, 
  where, 
  orderBy, 
  onSnapshot, 
  doc, 
  updateDoc,
  addDoc,
  serverTimestamp 
} from 'firebase/firestore';

import { sendMessage } from '../services/whatsappService';

interface Thread {
  id: string;
  name: string;
  lastMessage: string;
  time: string;
  status: 'ia' | 'human';
  unreadCount?: number;
  remoteJid: string;
  updatedAt: any;
}

interface Message {
  id: string;
  text: string;
  sender: 'lead' | 'ia' | 'outbound';
  time: string;
  timestamp: any;
}

const ContactItem: React.FC<{ thread: Thread, active: boolean, onClick: () => void }> = ({ thread, active, onClick }) => (
  <div 
    onClick={onClick}
    className={`p-4 flex items-start gap-3 cursor-pointer transition-colors border-b border-gray-50 last:border-0
      ${active ? 'bg-blue-50/50 border-l-4 border-l-blue-600' : 'hover:bg-gray-50 border-l-4 border-l-transparent'}`}
  >
    <div className="w-12 h-12 rounded-full bg-gray-200 flex-shrink-0 flex items-center justify-center text-gray-500 overflow-hidden">
      <User size={24} />
    </div>
    <div className="flex-1 min-w-0">
      <div className="flex items-center justify-between mb-1">
        <h4 className={`text-sm font-bold truncate ${active ? 'text-blue-600' : 'text-gray-900'}`}>{thread.name}</h4>
        <span className="text-[10px] text-gray-400 whitespace-nowrap">{thread.time}</span>
      </div>
      <p className="text-xs text-gray-500 truncate mb-2">{thread.lastMessage}</p>
      <div className="flex items-center justify-between">
        <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wider
          ${thread.status === 'ia' ? 'bg-green-100 text-green-700' : 'bg-orange-100 text-orange-700'}`}>
          {thread.status === 'ia' ? 'IA Atendendo' : 'Aguardando Humano'}
        </span>
        {thread.unreadCount && thread.unreadCount > 0 && (
          <span className="bg-blue-600 text-white text-[10px] font-bold w-4 h-4 rounded-full flex items-center justify-center">
            {thread.unreadCount}
          </span>
        )}
      </div>
    </div>
  </div>
);

const ChatBubble: React.FC<{ message: Message }> = ({ message }) => (
  <div className={`flex flex-col mb-4 ${message.sender !== 'lead' ? 'items-end' : 'items-start'}`}>
    <div className={`max-w-[80%] p-3 rounded-2xl text-sm shadow-sm relative
      ${message.sender !== 'lead' 
        ? 'bg-blue-600 text-white rounded-tr-none' 
        : 'bg-white text-gray-800 border border-gray-100 rounded-tl-none'}`}>
      {message.text}
      <div className={`flex items-center gap-1 mt-1 text-[10px] ${message.sender !== 'lead' ? 'text-blue-100' : 'text-gray-400'}`}>
        {message.time}
        {message.sender !== 'lead' && <CheckCheck size={12} />}
      </div>
    </div>
    {message.sender === 'ia' && (
      <div className="flex items-center gap-1 mt-1 mr-1">
        <Bot size={12} className="text-blue-600" />
        <span className="text-[10px] font-bold text-blue-600 uppercase tracking-tighter">IA Sofia</span>
      </div>
    )}
  </div>
);

export default function Inbox() {
  const [threads, setThreads] = useState<Thread[]>([]);
  const [selectedThreadId, setSelectedThreadId] = useState<string | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [messageText, setMessageText] = useState('');
  const [loadingThreads, setLoadingThreads] = useState(true);
  const [loadingMessages, setLoadingMessages] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Handle JID from URL
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const jid = params.get('jid');
    if (jid && threads.length > 0) {
      const thread = threads.find(t => t.remoteJid === jid);
      if (thread) {
        setSelectedThreadId(thread.id);
      }
    }
  }, [threads]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  // Listen to threads
  useEffect(() => {
    const user = auth.currentUser;
    if (!user) return;

    const q = query(
      collection(db, 'threads'),
      where('userId', '==', user.uid),
      orderBy('updatedAt', 'desc')
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const threadsData = snapshot.docs.map(doc => {
        const data = doc.data();
        return {
          id: doc.id,
          name: data.contactName || 'Lead WhatsApp',
          lastMessage: data.lastMessage || '',
          time: data.updatedAt?.toDate() ? new Intl.DateTimeFormat('pt-BR', { 
            hour: '2-digit', 
            minute: '2-digit',
            day: '2-digit',
            month: '2-digit'
          }).format(data.updatedAt.toDate()) : '',
          status: data.status || (data.unreadCount > 0 ? 'human' : 'ia'),
          unreadCount: data.unreadCount || 0,
          remoteJid: data.remoteJid,
          updatedAt: data.updatedAt
        } as Thread;
      });
      setThreads(threadsData);
      setLoadingThreads(false);
    });

    return () => unsubscribe();
  }, []);

  // Listen to messages
  useEffect(() => {
    if (!selectedThreadId) {
      setMessages([]);
      return;
    }

    setLoadingMessages(true);
    const q = query(
      collection(db, 'threads', selectedThreadId, 'messages'),
      orderBy('timestamp', 'asc')
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const messagesData = snapshot.docs.map(doc => {
        const data = doc.data();
        return {
          id: doc.id,
          text: data.text,
          sender: data.direction === 'inbound' ? 'lead' : (data.direction === 'outbound' && data.messageId.startsWith('ai-') ? 'ia' : 'outbound'),
          time: data.timestamp?.toDate() ? new Intl.DateTimeFormat('pt-BR', { hour: '2-digit', minute: '2-digit' }).format(data.timestamp.toDate()) : '',
          timestamp: data.timestamp
        } as Message;
      });
      setMessages(messagesData);
      setLoadingMessages(false);

      // Reset unread count
      const threadRef = doc(db, 'threads', selectedThreadId);
      updateDoc(threadRef, { unreadCount: 0 }).catch(console.error);
    });

    return () => unsubscribe();
  }, [selectedThreadId]);

  const activeThread = threads.find(t => t.id === selectedThreadId);

  const handleSendMessage = async () => {
    if (!messageText.trim() || !selectedThreadId || !activeThread) return;

    const user = auth.currentUser;
    if (!user) return;

    const text = messageText;
    setMessageText('');

    try {
      // Send via WhatsApp Service
      await sendMessage(activeThread.remoteJid, text);
      
      // Update thread status to 'human' when user sends a message
      const threadRef = doc(db, 'threads', selectedThreadId);
      await updateDoc(threadRef, { 
        status: 'human',
        lastMessage: text,
        updatedAt: serverTimestamp()
      });
      
      console.log('Message sent successfully');
    } catch (error) {
      console.error('Error sending message:', error);
    }
  };

  return (
    <div className="h-[calc(100vh-120px)] bg-white rounded-xl border border-gray-200 shadow-sm flex overflow-hidden">
      {/* Left Column: Contact List */}
      <div className="w-full md:w-[30%] border-r border-gray-100 flex flex-col bg-gray-50/30">
        <div className="p-4 border-b border-gray-100 bg-white">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
            <input 
              type="text" 
              placeholder="Buscar conversas..." 
              className="w-full pl-10 pr-4 py-2 bg-gray-100 border-transparent rounded-lg text-sm focus:bg-white focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all"
            />
          </div>
        </div>
        
        <div className="flex-1 overflow-y-auto">
          {loadingThreads ? (
            <div className="flex flex-col items-center justify-center h-32 text-gray-400">
              <Loader2 size={24} className="animate-spin mb-2" />
              <p className="text-xs">Carregando conversas...</p>
            </div>
          ) : threads.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-32 text-gray-400 p-4 text-center">
              <p className="text-xs">Nenhuma conversa encontrada.</p>
            </div>
          ) : (
            threads.map(thread => (
              <ContactItem 
                key={thread.id} 
                thread={thread} 
                active={selectedThreadId === thread.id}
                onClick={() => setSelectedThreadId(thread.id)}
              />
            ))
          )}
        </div>
      </div>

      {/* Right Column: Chat Area */}
      <div className="hidden md:flex flex-1 flex-col bg-white">
        {selectedThreadId && activeThread ? (
          <>
            {/* Chat Header */}
            <div className="h-16 px-6 border-b border-gray-100 flex items-center justify-between bg-white shrink-0">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center text-blue-600">
                  <User size={20} />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-gray-900">{activeThread.name}</h3>
                  <div className="flex items-center gap-1">
                    <span className="w-2 h-2 rounded-full bg-green-500"></span>
                    <span className="text-[10px] text-gray-500 font-medium">Online</span>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-4">
                <button className="px-4 py-2 bg-orange-50 text-orange-600 border border-orange-100 rounded-lg text-xs font-bold hover:bg-orange-100 transition-colors">
                  Assumir Atendimento
                </button>
                <div className="flex items-center gap-2 text-gray-400">
                  <button className="p-2 hover:bg-gray-50 rounded-lg"><Phone size={18} /></button>
                  <button className="p-2 hover:bg-gray-50 rounded-lg"><Video size={18} /></button>
                  <button className="p-2 hover:bg-gray-50 rounded-lg"><MoreVertical size={18} /></button>
                </div>
              </div>
            </div>

            {/* Messages Area */}
            <div className="flex-1 overflow-y-auto p-6 bg-[#f8f9fa] space-y-2">
              {loadingMessages ? (
                <div className="flex items-center justify-center h-full text-gray-400">
                  <Loader2 size={24} className="animate-spin" />
                </div>
              ) : (
                <>
                  {messages.map(msg => (
                    <ChatBubble key={msg.id} message={msg} />
                  ))}
                  <div ref={messagesEndRef} />
                </>
              )}
            </div>

            {/* Typing Bar */}
            <div className="p-4 border-t border-gray-100 bg-white shrink-0">
              <form 
                onSubmit={(e) => { e.preventDefault(); handleSendMessage(); }}
                className="flex items-center gap-3 bg-gray-50 p-2 rounded-xl border border-gray-200"
              >
                <button type="button" className="p-2 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-all">
                  <Paperclip size={20} />
                </button>
                <input 
                  type="text" 
                  value={messageText}
                  onChange={(e) => setMessageText(e.target.value)}
                  placeholder="Digite sua mensagem..." 
                  className="flex-1 bg-transparent border-none focus:ring-0 text-sm py-2"
                />
                <button 
                  type="submit"
                  className={`p-2 rounded-lg transition-all ${messageText.trim() ? 'bg-blue-600 text-white shadow-md shadow-blue-200' : 'text-gray-300'}`}
                  disabled={!messageText.trim()}
                >
                  <Send size={20} />
                </button>
              </form>
            </div>
          </>
        ) : (
          <div className="flex-1 flex flex-col items-center justify-center text-gray-400 p-8 text-center">
            <div className="w-20 h-20 bg-gray-50 rounded-full flex items-center justify-center mb-4">
              <MessageCircle size={40} className="text-gray-200" />
            </div>
            <h3 className="text-lg font-bold text-gray-900 mb-2">Sua Caixa de Entrada</h3>
            <p className="max-w-xs text-sm">Selecione uma conversa ao lado para visualizar as mensagens e interagir com seus leads.</p>
          </div>
        )}
      </div>

      {/* Mobile Placeholder for Chat (when on mobile) */}
      <div className="md:hidden flex-1 flex items-center justify-center p-8 text-center text-gray-400">
        <p className="text-sm">Selecione uma conversa para visualizar no desktop ou use a versão mobile otimizada.</p>
      </div>
    </div>
  );
}
