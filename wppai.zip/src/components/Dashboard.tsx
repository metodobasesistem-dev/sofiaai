import React, { useState, useEffect } from 'react';
import { 
  MessageCircle, 
  Users, 
  Calendar, 
  Settings, 
  LayoutGrid, 
  BarChart3, 
  Plug, 
  Clock, 
  Bot, 
  User, 
  Check, 
  Zap, 
  Sparkles, 
  ChevronDown, 
  CalendarX, 
  ArrowRight,
  Radio,
  MessageSquare,
  CheckCircle2,
  X,
  QrCode,
  Loader2,
  RefreshCw
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { getWhatsAppStatus, connectWhatsApp, listenToWhatsAppSession, WhatsAppStatusResponse } from '../services/whatsappService';
import { toast } from 'sonner';
import { auth } from '../firebase';

const QuickNavCard = ({ icon: Icon, title, subtitle, onClick }: { icon: any, title: string, subtitle: string, onClick?: () => void }) => (
  <div 
    onClick={onClick}
    className="bg-white p-4 rounded-xl border border-gray-100 shadow-sm hover:shadow-md transition-all cursor-pointer group"
  >
    <div className="flex items-center gap-3">
      <div className="w-10 h-10 rounded-lg bg-gray-50 flex items-center justify-center text-gray-400 group-hover:text-blue-600 group-hover:bg-blue-50 transition-colors">
        <Icon size={20} />
      </div>
      <div>
        <h4 className="text-sm font-bold text-gray-900">{title}</h4>
        <p className="text-[11px] text-gray-400">{subtitle}</p>
      </div>
    </div>
  </div>
);

const MetricCard = ({ icon: Icon, title, value }: { icon: any, title: string, value: string }) => (
  <div className="bg-white p-6 rounded-xl border border-gray-100 shadow-sm">
    <div className="flex items-center gap-2 text-gray-400 mb-4">
      <Icon size={16} />
      <span className="text-xs font-bold uppercase tracking-wider">{title}</span>
    </div>
    <h3 className="text-3xl font-black text-gray-900">{value}</h3>
  </div>
);

export default function Dashboard({ onTabChange }: { onTabChange?: (tab: string, subTab?: string) => void }) {
  const [isWhatsAppModalOpen, setIsWhatsAppModalOpen] = useState(false);
  const [whatsappStatus, setWhatsappStatus] = useState<WhatsAppStatusResponse | null>(null);
  const [isConnecting, setIsConnecting] = useState(false);

  // Real-time listener for WhatsApp status
  useEffect(() => {
    const user = auth.currentUser;
    if (!user) return;

    const unsubscribe = listenToWhatsAppSession(user.uid, (data) => {
      setWhatsappStatus(data);
      
      if (data.status === 'connected') {
        if (isWhatsAppModalOpen) {
          toast.success('WhatsApp conectado com sucesso!');
          setIsWhatsAppModalOpen(false);
        }
      }
    });

    return () => unsubscribe();
  }, [isWhatsAppModalOpen]);

  const handleConnect = async () => {
    if (whatsappStatus?.status === 'connected') {
      toast.info('WhatsApp já está conectado.');
      return;
    }
    try {
      setIsConnecting(true);
      await connectWhatsApp();
      setIsWhatsAppModalOpen(true);
    } catch (error: any) {
      console.error('Failed to connect WhatsApp:', error);
      const errorMsg = error.message || 'Erro ao iniciar conexão com WhatsApp';
      toast.error(errorMsg);
    } finally {
      setIsConnecting(false);
    }
  };

  const handleRefreshQr = async () => {
    try {
      setIsConnecting(true);
      await connectWhatsApp();
    } catch (error: any) {
      console.error('Failed to refresh QR:', error);
      const errorMsg = error.message || 'Erro ao atualizar QR Code';
      toast.error(errorMsg);
    } finally {
      setIsConnecting(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* 1. Banner de Conexão (Topo) */}
      <motion.div 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-green-50 border border-green-200 rounded-xl p-6 flex flex-col md:flex-row items-center justify-between gap-6"
      >
        <div className="flex items-center gap-5">
          <div className="w-14 h-14 bg-green-500 rounded-full flex items-center justify-center text-white shadow-lg shadow-green-200">
            <MessageCircle size={32} fill="currentColor" />
          </div>
          <div className="space-y-1">
            <h2 className="text-xl font-black text-green-900">Ative sua assistente no WhatsApp</h2>
            <p className="text-sm text-green-700 opacity-80">Conecte seu WhatsApp e deixe a IA cuidar do atendimento e dos agendamentos.</p>
            <div className="flex gap-2 mt-2">
              <span className="px-2 py-0.5 bg-green-100 text-green-700 text-[10px] font-bold uppercase rounded border border-green-200 flex items-center gap-1">
                <Zap size={10} /> Ativação instantânea
              </span>
              <span className="px-2 py-0.5 bg-green-100 text-green-700 text-[10px] font-bold uppercase rounded border border-green-200 flex items-center gap-1">
                <Clock size={10} /> Atendimento 24h
              </span>
            </div>
          </div>
        </div>
        <button 
          onClick={handleConnect}
          disabled={isConnecting}
          className={`whitespace-nowrap px-6 py-3 rounded-lg font-bold flex items-center gap-2 transition-all shadow-md disabled:opacity-50
            ${whatsappStatus?.status === 'connected' 
              ? 'bg-red-500 hover:bg-red-600 text-white shadow-red-200' 
              : 'bg-green-600 hover:bg-green-700 text-white shadow-green-200'}`}
        >
          {isConnecting ? <Loader2 size={18} className="animate-spin" /> : <Radio size={18} />}
          {whatsappStatus?.status === 'connected' ? 'Desconectar WhatsApp' : 'Conectar WhatsApp'}
        </button>
      </motion.div>

      {/* 2. Grid de Navegação Rápida */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <QuickNavCard 
          icon={Bot} 
          title="Agentes" 
          subtitle="Configure seu agente" 
          onClick={() => onTabChange?.('agents')}
        />
        <QuickNavCard 
          icon={MessageSquare} 
          title="Chats" 
          subtitle="Acompanhe suas conversas" 
          onClick={() => onTabChange?.('inbox')}
        />
        <QuickNavCard 
          icon={Calendar} 
          title="Agendamentos" 
          subtitle="Veja seus agendamentos" 
          onClick={() => onTabChange?.('schedule')}
        />
        <QuickNavCard 
          icon={Users} 
          title="Contatos" 
          subtitle="Gerencie seus contatos" 
          onClick={() => onTabChange?.('contacts')}
        />
        <QuickNavCard 
          icon={Clock} 
          title="Disponibilidade" 
          subtitle="Defina seus horários" 
          onClick={() => onTabChange?.('availability')}
        />
        <QuickNavCard 
          icon={Radio} 
          title="Canais" 
          subtitle="Gerencie seus canais" 
          onClick={() => onTabChange?.('settings', 'channels')}
        />
        <QuickNavCard 
          icon={Plug} 
          title="Integrações" 
          subtitle="Conecte suas ferramentas" 
          onClick={() => onTabChange?.('integrations')}
        />
        <QuickNavCard 
          icon={BarChart3} 
          title="Relatórios" 
          subtitle="Confira seus resultados" 
          onClick={() => onTabChange?.('dashboard')}
        />
      </div>

      {/* 3. Banner de Plano / Upsell */}
      <div className="bg-[#f0f9f9] border border-[#d1eeee] rounded-xl p-8 relative overflow-hidden">
        <div className="absolute top-0 right-0 p-8 text-[#2d7a7a] opacity-10">
          <Sparkles size={120} />
        </div>
        
        <div className="relative z-10">
          <div className="flex items-center gap-2 mb-2">
            <span className="px-2 py-0.5 bg-[#2d7a7a] text-white text-[10px] font-bold uppercase rounded flex items-center gap-1">
              <Zap size={10} fill="currentColor" /> Teste Grátis
            </span>
          </div>
          <h2 className="text-2xl font-black text-[#1a4d4d] mb-1">Escolha o melhor plano para você</h2>
          <p className="text-sm text-[#2d7a7a] opacity-80 mb-8">Escolha um plano e comece a transformar seu atendimento com nossa IA hoje mesmo</p>

          <div className="flex flex-col items-center justify-center mb-8">
            <p className="text-[10px] font-bold text-[#2d7a7a] uppercase tracking-widest mb-4 flex items-center gap-2">
              <Clock size={12} /> Tempo restante do teste grátis:
            </p>
            <div className="flex gap-4">
              {[
                { val: '6', label: 'dias' },
                { val: '20', label: 'horas' },
                { val: '49', label: 'min' },
                { val: '51', label: 'seg' }
              ].map((t, i) => (
                <div key={i} className="flex flex-col items-center">
                  <div className="w-14 h-14 bg-white rounded-lg border border-[#d1eeee] flex items-center justify-center text-xl font-black text-[#1a4d4d] shadow-sm">
                    {t.val}
                  </div>
                  <span className="text-[10px] font-bold text-[#2d7a7a] mt-1 uppercase">{t.label}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="space-y-2 mb-8 max-w-md">
            {[
              "Agenda automatizada com IA",
              "Agente personalizado para seu negócio",
              "Integração com WhatsApp"
            ].map((item, i) => (
              <div key={i} className="flex items-center gap-2 text-sm text-[#1a4d4d] font-medium">
                <CheckCircle2 size={16} className="text-green-500" />
                {item}
              </div>
            ))}
          </div>

          <div className="space-y-3">
            <button 
              onClick={() => onTabChange?.('settings', 'subscription')}
              className="w-full py-3 bg-[#2d7a7a] hover:bg-[#235e5e] text-white rounded-lg font-bold flex items-center justify-center gap-2 transition-all shadow-md shadow-[#2d7a7a]/20"
            >
              <LayoutGrid size={18} />
              Escolher Plano
            </button>
            <button className="w-full py-3 bg-white border border-[#2d7a7a] text-[#2d7a7a] hover:bg-[#f0f9f9] rounded-lg font-bold flex items-center justify-center gap-2 transition-all">
              <MessageCircle size={18} />
              Chamar consultor
            </button>
          </div>
        </div>
      </div>

      {/* 4. Seção de Métricas */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-black text-gray-900">Métricas</h2>
          <div className="flex items-center gap-2 bg-white border border-gray-200 px-3 py-1.5 rounded-lg text-xs font-bold text-gray-600 cursor-pointer hover:bg-gray-50 transition-all">
            Este Mês <ChevronDown size={14} />
          </div>
        </div>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          <MetricCard icon={Users} title="Novos Contatos" value="4" />
          <MetricCard icon={Calendar} title="Novos Agendamentos" value="0" />
          <MetricCard icon={BarChart3} title="Taxa de Comparecimento" value="0.0%" />
          <MetricCard icon={MessageSquare} title="Mensagens do Agente" value="3" />
        </div>
      </div>

      {/* 5. Painéis Inferiores (Split 50/50) */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Coluna Esquerda: Próximos Agendamentos */}
        <div className="bg-white rounded-xl border border-gray-100 shadow-sm flex flex-col min-h-[400px]">
          <div className="p-6 border-b border-gray-50 flex items-center justify-between">
            <h3 className="font-bold text-gray-900">Próximos Agendamentos</h3>
            <Calendar size={18} className="text-gray-400" />
          </div>
          
          <div className="flex-1 flex flex-col items-center justify-center p-8 text-center">
            <div className="w-16 h-16 bg-gray-50 rounded-2xl flex items-center justify-center text-gray-300 mb-4">
              <CalendarX size={32} />
            </div>
            <h4 className="text-sm font-bold text-gray-900">Nenhum agendamento próximo</h4>
            <p className="text-xs text-gray-400 mt-1 max-w-[200px]">Quando houver novos agendamentos, eles aparecerão aqui.</p>
          </div>

          <div className="p-4 bg-gray-50/50 border-t border-gray-50 text-center">
            <button className="text-xs font-bold text-gray-500 hover:text-blue-600 transition-colors">
              Ver todos os agendamentos
            </button>
          </div>
        </div>

        {/* Coluna Direita: Atividades Recentes */}
        <div className="bg-white rounded-xl border border-gray-100 shadow-sm flex flex-col min-h-[400px]">
          <div className="p-6 border-b border-gray-50 flex items-center justify-between">
            <h3 className="font-bold text-gray-900">Atividades Recentes</h3>
            <span className="bg-green-100 text-green-700 text-[10px] font-bold px-2 py-0.5 rounded-full">3</span>
          </div>
          
          <div className="p-6 space-y-4">
            {[
              { name: 'OralDents', phone: '(553288662080)', time: 'há cerca de 2 horas' },
              { name: 'Instituto Camarti', phone: '(553237217394)', time: 'há cerca de 2 horas' },
              { name: 'Dr Ramon ferraz', phone: '(553398220055)', time: 'há cerca de 3 horas' }
            ].map((activity, i) => (
              <div key={i} className="flex items-start gap-4 p-4 rounded-xl border border-gray-50 hover:bg-gray-50 transition-all cursor-pointer group">
                <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center text-blue-600 shrink-0 relative">
                  <User size={20} />
                  <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-white rounded-full flex items-center justify-center border border-gray-100">
                    <MessageCircle size={10} className="text-green-500" />
                  </div>
                </div>
                <div className="flex-1 min-w-0">
                  <h4 className="text-sm font-bold text-gray-900">Novo contato</h4>
                  <p className="text-xs text-gray-500 truncate">
                    {activity.name} entrou em contato pelo Whatsapp
                  </p>
                  <div className="flex items-center gap-2 mt-1">
                    <span className="text-[10px] font-bold text-blue-600">{activity.name} {activity.phone}</span>
                    <span className="text-[10px] text-gray-400">• {activity.time}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Modal Conectar WhatsApp */}
      <AnimatePresence>
        {isWhatsAppModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsWhatsAppModalOpen(false)}
              className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="bg-white rounded-3xl w-full max-w-2xl shadow-2xl overflow-hidden relative z-10"
            >
              {/* Header */}
              <div className="p-6 border-b border-gray-100 flex items-center justify-between">
                <h3 className="text-xl font-bold text-gray-900">Conectar ao WhatsApp</h3>
                <button 
                  onClick={() => setIsWhatsAppModalOpen(false)}
                  className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-xl transition-all"
                >
                  <X size={20} />
                </button>
              </div>

              {/* Content */}
              <div className="p-8 grid grid-cols-1 md:grid-cols-2 gap-12">
                {/* Instruções */}
                <div className="space-y-6">
                  {[
                    "Abra o WhatsApp no celular",
                    "Toque em Mais opções ou Configurações",
                    "Toque em Aparelhos conectados",
                    "Aponte a câmera para esta tela"
                  ].map((text, i) => (
                    <div key={i} className="flex gap-4 items-start">
                      <div className="w-7 h-7 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center text-xs font-bold shrink-0">
                        {i + 1}
                      </div>
                      <p className="text-sm text-gray-600 font-medium leading-relaxed pt-1">
                        {text}
                      </p>
                    </div>
                  ))}
                </div>

                {/* QR Code Placeholder */}
                <div className="flex flex-col items-center justify-center">
                  <div className="w-56 h-56 border-2 border-dashed border-gray-200 rounded-3xl flex items-center justify-center bg-gray-50/50 relative group overflow-hidden">
                    {whatsappStatus?.qr ? (
                      <img 
                        src={whatsappStatus.qr.startsWith('data:') ? whatsappStatus.qr : `data:image/png;base64,${whatsappStatus.qr}`} 
                        alt="WhatsApp QR Code" 
                        className="w-full h-full object-contain p-4"
                      />
                    ) : (
                      <QrCode size={120} className="text-gray-200 group-hover:text-emerald-500 transition-colors" />
                    )}
                    
                    {isConnecting && (
                      <div className="absolute inset-0 bg-white/80 backdrop-blur-[2px] flex items-center justify-center">
                        <Loader2 size={40} className="animate-spin text-emerald-500" />
                      </div>
                    )}

                    <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                      <button 
                        onClick={handleRefreshQr}
                        className="bg-white px-4 py-2 rounded-lg shadow-lg text-[10px] font-bold text-emerald-600 uppercase tracking-widest flex items-center gap-2 hover:bg-emerald-50 transition-all"
                      >
                        <RefreshCw size={12} />
                        Atualizar QR
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              {/* Footer */}
              <div className="p-6 bg-gray-50 flex flex-col items-center justify-center gap-2 border-t border-gray-100">
                <div className="flex items-center gap-3 text-gray-400 text-sm font-medium">
                  {whatsappStatus?.status === 'connected' ? (
                    <div className="flex items-center gap-2 text-emerald-600">
                      <Check size={18} />
                      WhatsApp Conectado!
                    </div>
                  ) : (
                    <>
                      <Loader2 size={18} className="animate-spin text-emerald-500" />
                      Aguardando leitura do QR Code…
                    </>
                  )}
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
