import React, { useState, useEffect } from 'react';
import { 
  User, 
  Building2, 
  CreditCard, 
  Check, 
  Zap, 
  ShieldCheck,
  ArrowRight,
  Lock,
  Loader2,
  Save,
  Key,
  MessageSquare,
  Plus,
  Trash2,
  Globe,
  Send,
  X,
  Smartphone
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  getUserProfile, 
  updateUserProfile, 
  UserProfile, 
  listChannels, 
  createChannel, 
  deleteChannel, 
  listAgents,
  Agent,
  Channel
} from '../services/firebaseService';
import { toast } from 'sonner';

interface PlanCardProps {
  name: string;
  price: string;
  benefits: string[];
  buttonText: string;
  popular?: boolean;
}

const PlanCard = ({ name, price, benefits, buttonText, popular }: PlanCardProps) => (
  <div className={`relative bg-white p-8 rounded-2xl border-2 transition-all flex flex-col h-full
    ${popular ? 'border-teal-600 shadow-xl shadow-teal-100 scale-105 z-10' : 'border-gray-100 shadow-sm hover:border-gray-200'}`}>
    
    {popular && (
      <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-teal-600 text-white text-[10px] font-bold uppercase tracking-widest px-4 py-1 rounded-full shadow-lg">
        Mais Popular
      </div>
    )}

    <div className="mb-6">
      <h3 className="text-xl font-bold text-gray-900">{name}</h3>
      <div className="mt-4 flex items-baseline gap-1">
        <span className="text-3xl font-black text-gray-900">{price}</span>
        <span className="text-gray-500 text-sm">/mês</span>
      </div>
    </div>

    <ul className="space-y-4 mb-8 flex-1">
      {benefits.map((benefit, index) => (
        <li key={index} className="flex items-start gap-3 text-sm text-gray-600">
          <div className={`mt-0.5 w-5 h-5 rounded-full flex items-center justify-center shrink-0 ${popular ? 'bg-teal-100 text-teal-600' : 'bg-gray-100 text-gray-400'}`}>
            <Check size={12} />
          </div>
          {benefit}
        </li>
      ))}
    </ul>

    <button className={`w-full py-3 rounded-xl text-sm font-bold transition-all flex items-center justify-center gap-2
      ${popular 
        ? 'bg-teal-600 text-white hover:bg-teal-700 shadow-md shadow-teal-200' 
        : 'bg-white border-2 border-gray-200 text-gray-700 hover:bg-gray-50'}`}>
      {buttonText}
      <ArrowRight size={16} />
    </button>
  </div>
);

import { 
  getWhatsAppStatus, 
  connectWhatsApp, 
  listenToWhatsAppSession, 
  WhatsAppStatusResponse 
} from '../services/whatsappService';
import { auth } from '../firebase';

export default function Settings({ initialSubTab = 'account' }: { initialSubTab?: string }) {
  const [activeSubTab, setActiveSubTab] = useState(initialSubTab);
  const [whatsappStatus, setWhatsappStatus] = useState<WhatsAppStatusResponse | null>(null);
  const [isWhatsAppModalOpen, setIsWhatsAppModalOpen] = useState(false);
  const [isConnecting, setIsConnecting] = useState(false);

  useEffect(() => {
    setActiveSubTab(initialSubTab);
  }, [initialSubTab]);

  // Real-time listener for WhatsApp status
  useEffect(() => {
    const user = auth.currentUser;
    if (!user) return;

    const unsubscribe = listenToWhatsAppSession(user.uid, (data) => {
      setWhatsappStatus(data);
      
      if (data.status === 'connected') {
        if (isWhatsAppModalOpen) {
          toast.success('WhatsApp conectado com sucesso!');
          setIsWhatsAppModalOpen(false);
        }
      }
    });

    return () => unsubscribe();
  }, [isWhatsAppModalOpen]);

  const handleConnectWpp = async () => {
    try {
      setIsConnecting(true);
      await connectWhatsApp();
      setIsWhatsAppModalOpen(true);
    } catch (error: any) {
      console.error('Failed to connect WhatsApp:', error);
      const errorMsg = error.message || 'Erro ao iniciar conexão com WhatsApp';
      toast.error(errorMsg);
    } finally {
      setIsConnecting(false);
    }
  };

  const handleDisconnectWpp = async () => {
    toast.info('Funcionalidade de desconexão em manutenção.');
  };

  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);

  // Channels State
  const [channels, setChannels] = useState<Channel[]>([]);
  const [agents, setAgents] = useState<Agent[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isCreatingChannel, setIsCreatingChannel] = useState(false);
  const [newChannelData, setNewChannelData] = useState({
    nome: '',
    agentId: '',
    tipo: 'whatsapp' as 'whatsapp' | 'chat' | 'telegram'
  });

  // Form State
  const [formData, setFormData] = useState({
    nome_completo: '',
    email: '',
    nome_empresa: '',
    whatsapp_organizacao: ''
  });

  const [passwordData, setPasswordData] = useState({
    currentPassword: '',
    newPassword: '',
    confirmPassword: ''
  });

  useEffect(() => {
    const fetchData = async () => {
      try {
        setIsLoading(true);
        const [profileData, channelsData, agentsData] = await Promise.all([
          getUserProfile(),
          listChannels(),
          listAgents()
        ]);

        if (profileData) {
          setProfile(profileData);
          setFormData({
            nome_completo: profileData.nome_completo || '',
            email: profileData.email || '',
            nome_empresa: profileData.nome_empresa || '',
            whatsapp_organizacao: profileData.whatsapp_organizacao || ''
          });
        }

        if (channelsData) setChannels(channelsData);
        if (agentsData) setAgents(agentsData);

      } catch (error) {
        console.error('Failed to fetch data:', error);
        toast.error('Erro ao carregar dados');
      } finally {
        setIsLoading(false);
      }
    };
    fetchData();
  }, []);

  const handleSaveProfile = async () => {
    try {
      setIsSaving(true);
      await updateUserProfile({
        nome_completo: formData.nome_completo,
        nome_empresa: formData.nome_empresa,
        whatsapp_organizacao: formData.whatsapp_organizacao
      });
      toast.success('Perfil atualizado com sucesso!');
    } catch (error) {
      console.error('Failed to update profile:', error);
      toast.error('Erro ao atualizar perfil');
    } finally {
      setIsSaving(false);
    }
  };

  const handleCreateChannel = async () => {
    if (!newChannelData.nome || !newChannelData.agentId) {
      toast.error('Preencha todos os campos obrigatórios');
      return;
    }

    try {
      setIsCreatingChannel(true);
      const created = await createChannel({
        nome: newChannelData.nome,
        agentId: newChannelData.agentId,
        tipo: newChannelData.tipo,
        status: 'ativo'
      });

      if (created) {
        setChannels([...channels, created as Channel]);
        setIsModalOpen(false);
        setNewChannelData({ nome: '', agentId: '', tipo: 'whatsapp' });
        toast.success('Canal criado com sucesso!');
      }
    } catch (error) {
      console.error('Failed to create channel:', error);
      toast.error('Erro ao criar canal');
    } finally {
      setIsCreatingChannel(false);
    }
  };

  const handleDeleteChannel = async (id: string) => {
    try {
      await deleteChannel(id);
      setChannels(channels.filter(c => c.id !== id));
      toast.success('Canal excluído com sucesso!');
    } catch (error) {
      console.error('Failed to delete channel:', error);
      toast.error('Erro ao excluir canal');
    }
  };

  const tabs = [
    { id: 'account', label: 'Conta', icon: <User size={18} /> },
    { id: 'subscription', label: 'Assinatura', icon: <CreditCard size={18} /> },
    { id: 'channels', label: 'Canais', icon: <MessageSquare size={18} /> },
  ];

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="animate-spin text-teal-600" size={32} />
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Configurações</h1>
        <p className="text-gray-500">Gerencie suas configurações e preferências de conta</p>
      </div>

      {/* Internal Tabs Navigation */}
      <div className="flex items-center gap-1 bg-gray-100 p-1 rounded-xl w-fit">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveSubTab(tab.id)}
            className={`flex items-center gap-2 px-6 py-2 rounded-lg text-sm font-semibold transition-all
              ${activeSubTab === tab.id 
                ? 'bg-white text-gray-900 shadow-sm' 
                : 'text-gray-500 hover:text-gray-700 hover:bg-gray-200/50'}`}
          >
            {tab.icon}
            {tab.label}
          </button>
        ))}
      </div>

      {/* Tab Content */}
      <AnimatePresence mode="wait">
        <motion.div
          key={activeSubTab}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -10 }}
          className="space-y-8"
        >
          {activeSubTab === 'account' && (
            <div className="space-y-8">
              {/* Perfil Section */}
              <div className="bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden">
                <div className="p-6 border-b border-gray-100">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-teal-50 text-teal-600 flex items-center justify-center">
                      <User size={20} />
                    </div>
                    <div>
                      <h3 className="text-lg font-bold text-gray-900">Perfil</h3>
                      <p className="text-sm text-gray-500">Gerencie suas informações pessoais e profissionais</p>
                    </div>
                  </div>
                </div>
                
                <div className="p-8 space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Nome completo</label>
                      <input 
                        type="text"
                        value={formData.nome_completo}
                        onChange={e => setFormData({...formData, nome_completo: e.target.value})}
                        placeholder="Seu nome completo"
                        className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-teal-500 focus:ring-2 focus:ring-teal-500/20 outline-none transition-all text-sm"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Email</label>
                      <input 
                        type="email"
                        disabled
                        value={formData.email}
                        placeholder="seu@email.com"
                        className="w-full px-4 py-3 rounded-xl border border-gray-200 bg-gray-50 text-gray-500 outline-none text-sm cursor-not-allowed"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Nome da Organização</label>
                      <input 
                        type="text"
                        value={formData.nome_empresa}
                        onChange={e => setFormData({...formData, nome_empresa: e.target.value})}
                        placeholder="Nome da sua empresa"
                        className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-teal-500 focus:ring-2 focus:ring-teal-500/20 outline-none transition-all text-sm"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">WhatsApp da Organização</label>
                      <input 
                        type="text"
                        value={formData.whatsapp_organizacao}
                        onChange={e => setFormData({...formData, whatsapp_organizacao: e.target.value})}
                        placeholder="Ex: 5511999999999"
                        className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-teal-500 focus:ring-2 focus:ring-teal-500/20 outline-none transition-all text-sm"
                      />
                    </div>
                  </div>

                  <div className="flex justify-end pt-4">
                    <button 
                      onClick={handleSaveProfile}
                      disabled={isSaving}
                      className="px-6 py-2.5 bg-teal-500/50 hover:bg-teal-500 text-white rounded-lg text-sm font-bold transition-all flex items-center gap-2 disabled:opacity-50"
                    >
                      {isSaving ? <Loader2 size={18} className="animate-spin" /> : <Save size={18} />}
                      Salvar alterações
                    </button>
                  </div>
                </div>
              </div>

              {/* Segurança Section */}
              <div className="bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden">
                <div className="p-6 border-b border-gray-100">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-teal-50 text-teal-600 flex items-center justify-center">
                      <Lock size={20} />
                    </div>
                    <div>
                      <h3 className="text-lg font-bold text-gray-900">Segurança</h3>
                      <p className="text-sm text-gray-500">Configure suas opções de segurança e acesso</p>
                    </div>
                  </div>
                </div>

                <div className="p-8 space-y-6">
                  <div className="max-w-md">
                    <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Senha atual</label>
                    <input 
                      type="password"
                      value={passwordData.currentPassword}
                      onChange={e => setPasswordData({...passwordData, currentPassword: e.target.value})}
                      placeholder="Sua senha atual"
                      className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-teal-500 focus:ring-2 focus:ring-teal-500/20 outline-none transition-all text-sm"
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Nova senha</label>
                      <input 
                        type="password"
                        value={passwordData.newPassword}
                        onChange={e => setPasswordData({...passwordData, newPassword: e.target.value})}
                        placeholder="Mínimo 8 caracteres"
                        className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-teal-500 focus:ring-2 focus:ring-teal-500/20 outline-none transition-all text-sm"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Confirmar nova senha</label>
                      <input 
                        type="password"
                        value={passwordData.confirmPassword}
                        onChange={e => setPasswordData({...passwordData, confirmPassword: e.target.value})}
                        placeholder="Repita a nova senha"
                        className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-teal-500 focus:ring-2 focus:ring-teal-500/20 outline-none transition-all text-sm"
                      />
                    </div>
                  </div>

                  <div className="flex justify-end pt-4">
                    <button 
                      className="px-6 py-2.5 bg-teal-500/50 hover:bg-teal-500 text-white rounded-lg text-sm font-bold transition-all flex items-center gap-2"
                    >
                      <Key size={18} />
                      Atualizar senha
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeSubTab === 'subscription' && (
            <div className="space-y-8">
              {/* Current Plan Banner */}
              <div className="bg-gradient-to-r from-teal-600 to-teal-800 rounded-2xl p-8 text-white shadow-xl shadow-teal-100 flex flex-col md:flex-row items-center justify-between gap-6">
                <div className="flex items-center gap-6">
                  <div className="w-16 h-16 bg-white/20 backdrop-blur-md rounded-2xl flex items-center justify-center">
                    <Zap size={32} className="text-white" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-teal-100 text-xs font-bold uppercase tracking-widest">Plano Atual</span>
                      <span className="bg-white/20 px-2 py-0.5 rounded text-[10px] font-bold uppercase">{profile?.plano || 'Starter'}</span>
                    </div>
                    <h2 className="text-2xl font-bold">Você está no plano {profile?.plano || 'Starter'}</h2>
                    <p className="text-teal-100 text-sm opacity-80 mt-1">Sua próxima cobrança será em 15 de Abril, 2024.</p>
                  </div>
                </div>
                <button className="px-6 py-3 bg-white/10 hover:bg-white/20 backdrop-blur-md border border-white/20 rounded-xl text-sm font-bold transition-all">
                  Cancelar Assinatura
                </button>
              </div>

              {/* Upgrade Section */}
              <div>
                <div className="flex items-center gap-3 mb-8">
                  <div className="w-10 h-10 bg-orange-50 text-orange-600 rounded-xl flex items-center justify-center">
                    <ShieldCheck size={24} />
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-gray-900">Fazer Upgrade</h3>
                    <p className="text-sm text-gray-500">Escolha o plano ideal para escalar seu atendimento.</p>
                  </div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 max-w-4xl mx-auto py-4">
                  <PlanCard 
                    name="Plano Pro"
                    price="R$ 197"
                    popular={true}
                    benefits={[
                      "Até 3 Agentes de IA ativos",
                      "1.000 conversas por mês",
                      "Integração Google Calendar",
                      "Suporte via E-mail",
                      "Dashboard de Métricas Avançado"
                    ]}
                    buttonText="Assinar Pro"
                  />
                  <PlanCard 
                    name="Plano Enterprise"
                    price="R$ 497"
                    benefits={[
                      "Agentes de IA Ilimitados",
                      "Conversas Ilimitadas",
                      "Integração Stripe e Webhooks",
                      "Suporte VIP 24/7",
                      "Treinamento personalizado da IA"
                    ]}
                    buttonText="Assinar Enterprise"
                  />
                </div>
              </div>
            </div>
          )}

          {activeSubTab === 'channels' && (
            <div className="space-y-6">
              <div className="bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden">
                <div className="p-6 border-b border-gray-100 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-teal-50 text-teal-600 flex items-center justify-center">
                      <Smartphone size={20} />
                    </div>
                    <div>
                      <h3 className="text-lg font-bold text-gray-900">Canais Conectados</h3>
                      <p className="text-sm text-gray-500">Gerencie os canais de comunicação da sua organização ({channels.length}/1 canais)</p>
                    </div>
                  </div>
                  <button 
                    onClick={() => setIsModalOpen(true)}
                    className="flex items-center gap-2 px-4 py-2 bg-teal-600 text-white rounded-lg text-sm font-bold hover:bg-teal-700 transition-all"
                  >
                    <Plus size={18} />
                    Novo Canal
                  </button>
                </div>

                <div className="p-8">
                  {channels.length === 0 ? (
                    <div className="flex flex-col items-center justify-center py-12 text-gray-400">
                      <p className="text-sm">Nenhum canal encontrado. Adicione um novo canal para começar.</p>
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                      {channels.map((channel) => (
                        <div key={channel.id} className="p-6 rounded-2xl border border-gray-100 bg-gray-50/50 hover:border-teal-200 transition-all group relative">
                          <button 
                            onClick={() => handleDeleteChannel(channel.id!)}
                            className="absolute top-4 right-4 p-2 text-gray-400 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-all"
                          >
                            <Trash2 size={16} />
                          </button>
                          
                          <div className="flex items-center gap-4 mb-4">
                            <div className="w-12 h-12 rounded-xl bg-white shadow-sm flex items-center justify-center text-teal-600">
                              {channel.tipo === 'whatsapp' ? <Smartphone size={24} /> : channel.tipo === 'chat' ? <Globe size={24} /> : <Send size={24} />}
                            </div>
                            <div>
                              <h4 className="font-bold text-gray-900">{channel.nome}</h4>
                              <p className="text-xs text-gray-500 capitalize">{channel.tipo}</p>
                            </div>
                          </div>
                          
                          <div className="flex items-center justify-between pt-4 border-t border-gray-100">
                            <div className="flex flex-col gap-1">
                              <span className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full w-fit ${channel.status === 'ativo' ? 'bg-green-100 text-green-600' : 'bg-gray-100 text-gray-500'}`}>
                                {channel.status}
                              </span>
                              {channel.tipo === 'whatsapp' && (
                                <span className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full w-fit ${whatsappStatus?.status === 'connected' ? 'bg-emerald-100 text-emerald-600' : 'bg-amber-100 text-amber-600'}`}>
                                  {whatsappStatus?.status === 'connected' ? 'Conectado' : whatsappStatus?.status === 'waiting' ? 'Conectando...' : 'Desconectado'}
                                </span>
                              )}
                            </div>
                            <div className="flex flex-col items-end gap-2">
                              <span className="text-xs text-gray-400">
                                Agente: {agents.find(a => a.id === channel.agentId)?.nome || 'Nenhum'}
                              </span>
                              {channel.tipo === 'whatsapp' && (
                                <button 
                                  onClick={whatsappStatus?.status === 'connected' ? handleDisconnectWpp : handleConnectWpp}
                                  className={`text-[10px] font-bold px-3 py-1 rounded-lg transition-all ${whatsappStatus?.status === 'connected' ? 'bg-red-50 text-red-600 hover:bg-red-100' : 'bg-emerald-50 text-emerald-600 hover:bg-emerald-100'}`}
                                >
                                  {whatsappStatus?.status === 'connected' ? 'Desconectar' : 'Conectar'}
                                </button>
                              )}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}
        </motion.div>
      </AnimatePresence>

      {/* WhatsApp Connection Modal */}
      <AnimatePresence>
        {isWhatsAppModalOpen && (
          <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-3xl shadow-2xl w-full max-w-2xl overflow-hidden"
            >
              <div className="p-6 border-b border-gray-100 flex items-center justify-between">
                <h3 className="text-xl font-bold text-gray-900">Conectar WhatsApp</h3>
                <button 
                  onClick={() => setIsWhatsAppModalOpen(false)}
                  className="p-2 hover:bg-gray-100 rounded-full transition-all text-gray-400"
                >
                  <X size={20} />
                </button>
              </div>

              <div className="p-8 grid grid-cols-1 md:grid-cols-2 gap-12">
                <div className="space-y-6">
                  {[
                    "Abra o WhatsApp no celular",
                    "Toque em Mais opções ou Configurações",
                    "Toque em Aparelhos conectados",
                    "Aponte a câmera para esta tela"
                  ].map((text, i) => (
                    <div key={i} className="flex gap-4 items-start">
                      <div className="w-7 h-7 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center text-xs font-bold shrink-0">
                        {i + 1}
                      </div>
                      <p className="text-sm text-gray-600 font-medium leading-relaxed pt-1">
                        {text}
                      </p>
                    </div>
                  ))}
                </div>

                <div className="flex flex-col items-center justify-center">
                  <div className="w-56 h-56 border-2 border-dashed border-gray-200 rounded-3xl flex items-center justify-center bg-gray-50/50 relative group overflow-hidden">
                    {whatsappStatus?.qr ? (
                      <img 
                        src={whatsappStatus.qr.startsWith('data:') ? whatsappStatus.qr : `data:image/png;base64,${whatsappStatus.qr}`} 
                        alt="WhatsApp QR Code" 
                        className="w-full h-full object-contain p-4"
                      />
                    ) : (
                      <div className="flex flex-col items-center gap-2 text-gray-300">
                        <Smartphone size={64} />
                        <span className="text-[10px] font-bold uppercase tracking-widest">Gerando QR...</span>
                      </div>
                    )}
                    
                    {isConnecting && (
                      <div className="absolute inset-0 bg-white/80 backdrop-blur-[2px] flex items-center justify-center">
                        <Loader2 size={40} className="animate-spin text-emerald-500" />
                      </div>
                    )}
                  </div>
                </div>
              </div>

              <div className="p-6 bg-gray-50 flex flex-col items-center justify-center gap-2 border-t border-gray-100">
                <div className="flex items-center gap-3 text-gray-400 text-sm font-medium">
                  {whatsappStatus?.status === 'connected' ? (
                    <div className="flex items-center gap-2 text-emerald-600">
                      <Check size={18} />
                      WhatsApp Conectado!
                    </div>
                  ) : (
                    <>
                      <Loader2 size={18} className="animate-spin text-emerald-500" />
                      Aguardando leitura do QR Code…
                    </>
                  )}
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Add Channel Modal */}
      <AnimatePresence>
        {isModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-3xl shadow-2xl w-full max-w-lg overflow-hidden"
            >
              <div className="p-6 border-b border-gray-100 flex items-center justify-between">
                <div>
                  <h2 className="text-xl font-bold text-gray-900">Adicionar Novo Canal</h2>
                  <p className="text-sm text-gray-500">Conecte um novo canal de comunicação para expandir seu alcance.</p>
                </div>
                <button 
                  onClick={() => setIsModalOpen(false)}
                  className="p-2 hover:bg-gray-100 rounded-full transition-all text-gray-400"
                >
                  <X size={20} />
                </button>
              </div>

              <div className="p-8 space-y-6">
                <div>
                  <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Nome do Canal</label>
                  <input 
                    type="text"
                    value={newChannelData.nome}
                    onChange={e => setNewChannelData({...newChannelData, nome: e.target.value})}
                    placeholder="Ex: WhatsApp Principal, Atendimento Site"
                    className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-teal-500 focus:ring-2 focus:ring-teal-500/20 outline-none transition-all text-sm"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Agente Responsável</label>
                  <select 
                    value={newChannelData.agentId}
                    onChange={e => setNewChannelData({...newChannelData, agentId: e.target.value})}
                    className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-teal-500 focus:ring-2 focus:ring-teal-500/20 outline-none transition-all text-sm appearance-none bg-white"
                  >
                    <option value="">Selecione um agente</option>
                    {agents.map(agent => (
                      <option key={agent.id} value={agent.id}>{agent.nome}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Tipo de Canal</label>
                  <div className="grid grid-cols-2 gap-4">
                    <button 
                      onClick={() => setNewChannelData({...newChannelData, tipo: 'whatsapp'})}
                      className={`p-4 rounded-2xl border-2 transition-all flex items-center gap-3 text-left
                        ${newChannelData.tipo === 'whatsapp' ? 'border-teal-600 bg-teal-50/50' : 'border-gray-100 hover:border-gray-200'}`}
                    >
                      <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${newChannelData.tipo === 'whatsapp' ? 'bg-teal-600 text-white' : 'bg-gray-100 text-gray-400'}`}>
                        <Smartphone size={20} />
                      </div>
                      <div>
                        <span className="block text-sm font-bold text-gray-900">WhatsApp</span>
                      </div>
                    </button>

                    <div className="p-4 rounded-2xl border-2 border-gray-50 bg-gray-50/50 opacity-60 flex items-center gap-3 text-left cursor-not-allowed relative">
                      <div className="w-10 h-10 rounded-xl bg-gray-100 text-gray-400 flex items-center justify-center">
                        <Globe size={20} />
                      </div>
                      <div>
                        <span className="block text-sm font-bold text-gray-900">Chat no Site</span>
                        <span className="text-[10px] font-bold text-gray-400 uppercase tracking-tighter">Em breve</span>
                      </div>
                    </div>

                    <div className="p-4 rounded-2xl border-2 border-gray-50 bg-gray-50/50 opacity-60 flex items-center gap-3 text-left cursor-not-allowed relative">
                      <div className="w-10 h-10 rounded-xl bg-gray-100 text-gray-400 flex items-center justify-center">
                        <Send size={20} />
                      </div>
                      <div>
                        <span className="block text-sm font-bold text-gray-900">Telegram</span>
                        <span className="text-[10px] font-bold text-gray-400 uppercase tracking-tighter">Em breve</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="p-6 bg-gray-50 flex items-center justify-end gap-3">
                <button 
                  onClick={() => setIsModalOpen(false)}
                  className="px-6 py-2.5 text-sm font-bold text-gray-500 hover:text-gray-700 transition-all"
                >
                  Cancelar
                </button>
                <button 
                  onClick={handleCreateChannel}
                  disabled={isCreatingChannel}
                  className="px-8 py-2.5 bg-teal-600 text-white rounded-xl text-sm font-bold hover:bg-teal-700 transition-all disabled:opacity-50 flex items-center gap-2"
                >
                  {isCreatingChannel && <Loader2 size={18} className="animate-spin" />}
                  Criar Canal
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
