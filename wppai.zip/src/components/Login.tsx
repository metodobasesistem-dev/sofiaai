import React, { useState } from 'react';
import { Bot, LogIn, Loader2 } from 'lucide-react';
import { signInWithGoogle } from '../firebase';
import { motion } from 'motion/react';
import { toast } from 'sonner';

export default function Login() {
  const [isLoading, setIsLoading] = useState(false);

  const handleLogin = async () => {
    try {
      setIsLoading(true);
      await signInWithGoogle();
    } catch (error) {
      console.error('Login failed:', error);
      toast.error('Falha ao entrar com Google. Tente novamente.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col items-center justify-center p-4">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md bg-white rounded-3xl shadow-xl border border-gray-100 p-8 text-center"
      >
        <div className="w-16 h-16 bg-blue-600 rounded-2xl flex items-center justify-center text-white mx-auto mb-6 shadow-lg shadow-blue-200">
          <Bot size={32} />
        </div>
        
        <h1 className="text-2xl font-bold text-gray-900 mb-2">Bem-vindo ao WppAI</h1>
        <p className="text-gray-500 mb-8">Acesse sua conta para gerenciar seus agentes de IA e automações.</p>

        <button
          onClick={handleLogin}
          disabled={isLoading}
          className="w-full py-4 bg-white border-2 border-gray-100 rounded-2xl font-bold text-gray-700 hover:border-blue-600 hover:text-blue-600 transition-all flex items-center justify-center gap-3 group disabled:opacity-70"
        >
          {isLoading ? (
            <Loader2 size={20} className="animate-spin text-blue-600" />
          ) : (
            <>
              <img src="https://www.google.com/favicon.ico" alt="Google" className="w-5 h-5" />
              Entrar com Google
            </>
          )}
        </button>

        <p className="mt-8 text-xs text-gray-400">
          Ao entrar, você concorda com nossos Termos de Serviço e Política de Privacidade.
        </p>
      </motion.div>
    </div>
  );
}
