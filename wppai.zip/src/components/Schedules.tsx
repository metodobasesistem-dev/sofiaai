import React, { useState } from 'react';
import { 
  Calendar as CalendarIcon, 
  List, 
  Clock, 
  User, 
  Bot, 
  CalendarDays,
  MoreVertical,
  XCircle,
  RefreshCw
} from 'lucide-react';
import { motion } from 'motion/react';

interface Appointment {
  id: number;
  date: string;
  time: string;
  clientName: string;
  service: string;
  agent: string;
}

const AppointmentCard: React.FC<{ appointment: Appointment }> = ({ appointment }) => (
  <motion.div 
    initial={{ opacity: 0, y: 10 }}
    animate={{ opacity: 1, y: 0 }}
    className="bg-white p-5 rounded-xl border border-gray-200 shadow-sm hover:shadow-md transition-all flex flex-col sm:flex-row items-start sm:items-center gap-6"
  >
    {/* Date & Time Section */}
    <div className="flex flex-row sm:flex-col items-center justify-center bg-blue-50 rounded-xl p-4 min-w-[100px] text-blue-600 border border-blue-100">
      <span className="text-xs font-bold uppercase tracking-wider opacity-70">{appointment.date.split(' ')[0]}</span>
      <span className="text-2xl font-black leading-none my-1">{appointment.date.split(' ')[1]}</span>
      <div className="flex items-center gap-1 text-xs font-bold">
        <Clock size={12} />
        {appointment.time}
      </div>
    </div>

    {/* Info Section */}
    <div className="flex-1 space-y-1">
      <div className="flex items-center gap-2">
        <h3 className="text-lg font-bold text-gray-900">{appointment.clientName}</h3>
        <span className="px-2 py-0.5 bg-gray-100 text-gray-600 rounded text-[10px] font-bold uppercase tracking-wide">
          {appointment.service}
        </span>
      </div>
      <div className="flex items-center gap-2 text-sm text-gray-500">
        <Bot size={14} className="text-blue-500" />
        <span>Marcado por <span className="font-semibold text-gray-700">{appointment.agent}</span></span>
      </div>
    </div>

    {/* Actions Section */}
    <div className="flex items-center gap-2 w-full sm:w-auto mt-4 sm:mt-0">
      <button className="flex-1 sm:flex-none flex items-center justify-center gap-2 px-4 py-2 bg-white border border-gray-200 rounded-lg text-sm font-semibold text-gray-700 hover:bg-gray-50 transition-colors">
        <RefreshCw size={16} className="text-gray-400" />
        Reagendar
      </button>
      <button className="flex-1 sm:flex-none flex items-center justify-center gap-2 px-4 py-2 bg-white border border-red-100 rounded-lg text-sm font-semibold text-red-600 hover:bg-red-50 transition-colors">
        <XCircle size={16} />
        Cancelar
      </button>
      <button className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg transition-all hidden md:block">
        <MoreVertical size={20} />
      </button>
    </div>
  </motion.div>
);

export default function Schedules() {
  const [view, setView] = useState<'list' | 'calendar'>('list');

  const appointments: Appointment[] = [
    { id: 1, date: 'MAR 26', time: '14:30', clientName: 'Roberto Almeida', service: 'Terapia', agent: 'Sofia' },
    { id: 2, date: 'MAR 27', time: '10:00', clientName: 'Juliana Mendes', service: 'Barbearia', agent: 'Lucas' },
    { id: 3, date: 'MAR 28', time: '16:15', clientName: 'Fábio Silveira', service: 'Imobiliária', agent: 'Clara' },
  ];

  return (
    <div className="space-y-8">
      {/* Header Section */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Agendamentos</h1>
          <p className="text-gray-500 text-sm">Visualize e gerencie os compromissos marcados pela IA.</p>
        </div>
        
        <div className="flex items-center bg-white p-1 rounded-xl border border-gray-200 shadow-sm">
          <button 
            onClick={() => setView('list')}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-semibold transition-all
              ${view === 'list' ? 'bg-blue-600 text-white shadow-md shadow-blue-200' : 'text-gray-500 hover:bg-gray-50'}`}
          >
            <List size={18} />
            Lista
          </button>
          <button 
            onClick={() => setView('calendar')}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-semibold transition-all
              ${view === 'calendar' ? 'bg-blue-600 text-white shadow-md shadow-blue-200' : 'text-gray-500 hover:bg-gray-50'}`}
          >
            <CalendarIcon size={18} />
            Calendário
          </button>
        </div>
      </div>

      {view === 'list' ? (
        <div className="space-y-4">
          <div className="flex items-center gap-2 text-gray-400 mb-2">
            <CalendarDays size={16} />
            <span className="text-xs font-bold uppercase tracking-widest">Próximos Dias</span>
          </div>
          
          <div className="grid grid-cols-1 gap-4">
            {appointments.map((appointment) => (
              <AppointmentCard key={appointment.id} appointment={appointment} />
            ))}
          </div>

          {/* Empty State / Load More */}
          <div className="pt-4 flex justify-center">
            <button className="text-sm font-semibold text-blue-600 hover:text-blue-700 flex items-center gap-2">
              Ver agendamentos passados
            </button>
          </div>
        </div>
      ) : (
        <div className="bg-white rounded-2xl border border-gray-200 shadow-sm p-12 flex flex-col items-center justify-center text-gray-400 min-h-[400px]">
          <CalendarIcon size={64} className="mb-4 opacity-20" />
          <h3 className="text-lg font-bold text-gray-900">Visualização de Calendário</h3>
          <p className="text-sm mt-1">Esta funcionalidade está sendo preparada para você.</p>
          <button 
            onClick={() => setView('list')}
            className="mt-6 px-6 py-2 bg-blue-50 text-blue-600 rounded-lg text-sm font-bold hover:bg-blue-100 transition-colors"
          >
            Voltar para Lista
          </button>
        </div>
      )}
    </div>
  );
}
