import React, { useState, useEffect } from 'react';
import { 
  MessageCircle, 
  Calendar, 
  CreditCard, 
  ExternalLink, 
  CheckCircle2, 
  AlertCircle,
  Settings,
  QrCode,
  X,
  Loader2,
  RefreshCw,
  Smartphone
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { toast } from 'sonner';
import { getUserProfile, updateWhatsAppStatus, type UserProfile } from '../services/firebaseService';
import { auth } from '../firebase';
import WhatsAppWebJsConnect from './WhatsAppWebJsConnect';

interface IntegrationCardProps {
  icon: React.ReactNode;
  iconBg: string;
  iconColor: string;
  title: string;
  description: string;
  status: 'connected' | 'disconnected' | 'connecting';
  buttonText: string;
  buttonVariant?: 'primary' | 'secondary';
  onClick?: () => void;
  isLoading?: boolean;
}

const IntegrationCard = ({ 
  icon, 
  iconBg, 
  iconColor, 
  title, 
  description, 
  status, 
  buttonText, 
  buttonVariant = 'secondary',
  onClick,
  isLoading = false
}: IntegrationCardProps) => {
  return (
    <motion.div 
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      className="bg-white rounded-xl border border-gray-200 shadow-sm hover:shadow-md transition-all p-6 flex flex-col"
    >
      <div className="flex items-start justify-between mb-4">
        <div className={`w-12 h-12 rounded-xl ${iconBg} ${iconColor} flex items-center justify-center shadow-sm`}>
          {icon}
        </div>
        {status === 'connected' ? (
          <span className="flex items-center gap-1 text-[10px] font-bold uppercase tracking-wider text-green-600 bg-green-50 px-2 py-1 rounded-full border border-green-100">
            <CheckCircle2 size={12} /> Conectado
          </span>
        ) : status === 'connecting' ? (
          <span className="flex items-center gap-1 text-[10px] font-bold uppercase tracking-wider text-blue-600 bg-blue-50 px-2 py-1 rounded-full border border-blue-100">
            <Loader2 size={12} className="animate-spin" /> Conectando
          </span>
        ) : (
          <span className="flex items-center gap-1 text-[10px] font-bold uppercase tracking-wider text-red-600 bg-red-50 px-2 py-1 rounded-full border border-red-100">
            <AlertCircle size={12} /> Desconectado
          </span>
        )}
      </div>

      <div className="flex-1">
        <h3 className="text-lg font-bold text-gray-900 mb-2">{title}</h3>
        <p className="text-sm text-gray-500 leading-relaxed">
          {description}
        </p>
      </div>

      <div className="mt-6 pt-6 border-t border-gray-50 flex items-center justify-between gap-4">
        <button 
          onClick={onClick}
          disabled={isLoading}
          className={`flex-1 flex items-center justify-center gap-2 px-4 py-2 rounded-lg text-sm font-semibold transition-all disabled:opacity-70
          ${buttonVariant === 'primary' 
            ? 'bg-blue-600 text-white hover:bg-blue-700 shadow-sm shadow-blue-200' 
            : 'bg-white border border-gray-200 text-gray-700 hover:bg-gray-50'
          }`}
        >
          {isLoading ? (
            <Loader2 size={16} className="animate-spin" />
          ) : (
            <>
              {buttonText === 'Gerar QR Code' && <QrCode size={16} />}
              {buttonText === 'Conectando...' && <Loader2 size={16} className="animate-spin" />}
              {buttonText === 'Configurar' && <Settings size={16} />}
              {buttonText === 'Conectar' && <ExternalLink size={16} />}
              {buttonText === 'Desconectar' && <X size={16} />}
            </>
          )}
          {buttonText}
        </button>
      </div>
    </motion.div>
  );
};

export default function Integrations() {
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [isLoadingProfile, setIsLoadingProfile] = useState(true);
  const [isQRModalOpen, setIsQRModalOpen] = useState(false);
  const [isFetchingQR, setIsFetchingQR] = useState(false);
  const [qrCodeUrl, setQrCodeUrl] = useState<string | null>(null);

  const fetchProfile = async () => {
    const user = auth.currentUser;
    if (!user) return;

    try {
      setIsLoadingProfile(true);
      const profile = await getUserProfile();
      setUserProfile(profile);
    } catch (error) {
      console.error('Failed to fetch profile:', error);
    } finally {
      setIsLoadingProfile(false);
    }
  };

  useEffect(() => {
    fetchProfile();
  }, []);

  useEffect(() => {
    let pollInterval: NodeJS.Timeout;

    const poll = async () => {
      const user = auth.currentUser;
      if (!user || !isQRModalOpen) return;

      try {
        const token = await user.getIdToken();
        const response = await fetch('/api/channels/whatsapp/status', {
          headers: {
            'Authorization': `Bearer ${token}`
          }
        });

        if (response.ok) {
          const data = await response.json();
          if (data.status === 'connected') {
            setIsQRModalOpen(false);
            await fetchProfile();
            toast.success('WhatsApp conectado com sucesso!');
          } else if (isQRModalOpen) {
            pollInterval = setTimeout(poll, 5000);
          }
        } else if (isQRModalOpen) {
          pollInterval = setTimeout(poll, 5000);
        }
      } catch (error) {
        console.error('Polling error:', error);
        if (isQRModalOpen) {
          pollInterval = setTimeout(poll, 5000);
        }
      }
    };

    if (isQRModalOpen && qrCodeUrl) {
      poll();
    }

    return () => {
      if (pollInterval) clearTimeout(pollInterval);
    };
  }, [isQRModalOpen, qrCodeUrl]);

  const fetchQRCode = async () => {
    const user = auth.currentUser;
    if (!user) return;

    try {
      setIsFetchingQR(true);
      setQrCodeUrl(null);
      
      const token = await user.getIdToken();
      const response = await fetch('/api/channels/whatsapp/connect', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.error || 'Failed to connect WhatsApp');
      }
      
      const data = await response.json();
      setQrCodeUrl(data.qrCode);
      if (data.status === 'connected') {
        setIsQRModalOpen(false);
        await fetchProfile();
        toast.success('WhatsApp já está conectado!');
      }
    } catch (error: any) {
      console.error('Failed to fetch QR Code:', error);
      toast.error(error.message || 'Erro ao gerar QR Code. Tente novamente.');
      setIsQRModalOpen(false);
    } finally {
      setIsFetchingQR(false);
    }
  };

  const handleConnectWhatsApp = () => {
    setIsQRModalOpen(true);
    fetchQRCode();
  };

  const handleDisconnect = async () => {
    const user = auth.currentUser;
    if (!user) return;

    try {
      setIsFetchingQR(true); // Reuse loading state
      const token = await user.getIdToken();
      const response = await fetch('/api/channels/whatsapp/disconnect', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });

      if (response.ok) {
        await fetchProfile();
        toast.success('WhatsApp desconectado com sucesso!');
      } else {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.error || 'Failed to disconnect');
      }
    } catch (error: any) {
      console.error('Failed to disconnect:', error);
      toast.error(error.message || 'Erro ao desconectar. Tente novamente.');
    } finally {
      setIsFetchingQR(false);
    }
  };

  const whatsappStatus = userProfile?.whatsapp_status === 'connected' 
    ? 'connected' 
    : userProfile?.whatsapp_status === 'connecting' 
      ? 'connecting' 
      : 'disconnected';

  return (
    <div className="space-y-8">
      {/* Header Section */}
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Integrações</h1>
        <p className="text-gray-500 text-sm">Conecte seus canais e ferramentas ao WppAI para automatizar seu fluxo de trabalho.</p>
      </div>

      {/* Integrations Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <IntegrationCard 
          icon={<MessageCircle size={24} />}
          iconBg="bg-green-50"
          iconColor="text-green-600"
          title="WhatsApp Provider"
          description="Conecte seu número de WhatsApp para que seus agentes de IA possam responder seus clientes automaticamente."
          status={whatsappStatus}
          buttonText={whatsappStatus === 'connected' ? 'Desconectar' : whatsappStatus === 'connecting' ? 'Conectando...' : 'Gerar QR Code'}
          buttonVariant={whatsappStatus === 'connected' ? 'secondary' : 'primary'}
          onClick={whatsappStatus === 'connected' ? handleDisconnect : handleConnectWhatsApp}
          isLoading={isLoadingProfile}
        />

        <IntegrationCard 
          icon={<Calendar size={24} />}
          iconBg="bg-blue-50"
          iconColor="text-blue-600"
          title="Google Calendar"
          description="Sincronize os agendamentos feitos pela IA diretamente na sua agenda do Google para evitar conflitos de horário."
          status="connected"
          buttonText="Configurar"
          buttonVariant="secondary"
        />

        <IntegrationCard 
          icon={<CreditCard size={24} />}
          iconBg="bg-purple-50"
          iconColor="text-purple-600"
          title="Stripe"
          description="Receba pagamentos e crie links de cobrança diretamente nas conversas do WhatsApp através da nossa integração."
          status="disconnected"
          buttonText="Conectar"
          buttonVariant="secondary"
        />
      </div>

      {/* WhatsApp Web JS Section */}
      <div className="mt-12">
        <h3 className="text-sm font-bold text-gray-400 uppercase tracking-widest mb-6">Conexão Direta</h3>
        <div className="max-w-xl">
          <WhatsAppWebJsConnect />
        </div>
      </div>

      {/* Coming Soon Section */}
      <div className="mt-12">
        <h3 className="text-sm font-bold text-gray-400 uppercase tracking-widest mb-6">Em breve</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 opacity-60 grayscale">
          <div className="bg-white p-6 rounded-xl border border-gray-100 flex items-center gap-4">
            <div className="w-10 h-10 bg-gray-100 rounded-lg flex items-center justify-center text-gray-400">
              <span className="font-bold text-xs">CRM</span>
            </div>
            <div>
              <p className="text-sm font-bold text-gray-900">HubSpot</p>
              <p className="text-xs text-gray-500">Sincronização de leads</p>
            </div>
          </div>
          <div className="bg-white p-6 rounded-xl border border-gray-100 flex items-center gap-4">
            <div className="w-10 h-10 bg-gray-100 rounded-lg flex items-center justify-center text-gray-400">
              <span className="font-bold text-xs">API</span>
            </div>
            <div>
              <p className="text-sm font-bold text-gray-900">Webhooks</p>
              <p className="text-xs text-gray-500">Integração personalizada</p>
            </div>
          </div>
        </div>
      </div>

      {/* QR Code Modal */}
      <AnimatePresence>
        {isQRModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsQRModalOpen(false)}
              className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="bg-white rounded-3xl w-full max-w-md shadow-2xl overflow-hidden relative z-10"
            >
              <div className="p-6 border-b border-gray-100 flex items-center justify-between bg-gray-50/50">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-green-600 text-white flex items-center justify-center shadow-lg shadow-green-200">
                    <MessageCircle size={20} />
                  </div>
                  <h3 className="text-lg font-bold text-gray-900">Conectar WhatsApp</h3>
                </div>
                <button 
                  onClick={() => setIsQRModalOpen(false)}
                  className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-xl transition-all"
                >
                  <X size={20} />
                </button>
              </div>

              <div className="p-8 flex flex-col items-center text-center">
                <div className="mb-6">
                  <p className="text-sm text-gray-600 mb-4">
                    Abra o WhatsApp no seu celular, vá em <strong>Aparelhos Conectados</strong> e escaneie o código abaixo.
                  </p>
                </div>

                <div className="relative w-64 h-64 bg-gray-50 rounded-2xl border-2 border-dashed border-gray-200 flex items-center justify-center overflow-hidden">
                  {isFetchingQR ? (
                    <div className="flex flex-col items-center gap-2">
                      <Loader2 size={32} className="animate-spin text-blue-500" />
                      <span className="text-xs font-medium text-gray-400">Gerando QR Code...</span>
                    </div>
                  ) : qrCodeUrl ? (
                    <img 
                      src={qrCodeUrl} 
                      alt="WhatsApp QR Code" 
                      className="w-full h-full p-4"
                      referrerPolicy="no-referrer"
                    />
                  ) : (
                    <div className="flex flex-col items-center gap-2">
                      <AlertCircle size={32} className="text-red-400" />
                      <span className="text-xs font-medium text-gray-400">Erro ao gerar código</span>
                      <button onClick={fetchQRCode} className="text-xs text-blue-600 font-bold hover:underline">Tentar novamente</button>
                    </div>
                  )}
                </div>

                <div className="mt-8 w-full space-y-3">
                  <div className="flex items-center gap-2 justify-center text-xs text-gray-400 bg-gray-50 py-2 rounded-lg">
                    <Smartphone size={14} />
                    <span>Mantenha seu celular conectado à internet</span>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
