import React, { useState, useEffect } from 'react';
import { 
  Plus, 
  MessageSquare, 
  Settings2, 
  MoreVertical,
  Bot,
  CheckCircle2,
  AlertCircle,
  X,
  Loader2,
  Sparkles,
  User,
  Building2,
  Eye,
  Settings,
  ArrowLeft,
  Save,
  Trash2,
  Send,
  RotateCcw,
  Mic
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { listAgents, createAgent, updateAgent, toggleAgentStatus, type Agent } from '../services/firebaseService';

interface AgentCardProps {
  agent: Agent;
  onToggle: () => void;
  onEdit: () => void;
}

const AgentCard: React.FC<AgentCardProps> = ({ agent, onToggle, onEdit }) => {
  const status = agent.status_ativo ? 'active' : 'inactive';

  return (
    <motion.div 
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      className="bg-white rounded-xl border border-gray-200 shadow-sm hover:shadow-md transition-all p-6 flex flex-col"
    >
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-center gap-4">
          <div className={`w-12 h-12 rounded-full flex items-center justify-center ${status === 'active' ? 'bg-blue-50 text-blue-600' : 'bg-gray-50 text-gray-400'}`}>
            <Bot size={24} />
          </div>
          <div>
            <h3 className="font-bold text-gray-900">{agent.nome}</h3>
            <p className="text-sm text-gray-500">{agent.nicho || 'Sem nicho'}</p>
          </div>
        </div>
        <button className="text-gray-400 hover:text-gray-600 p-1">
          <MoreVertical size={20} />
        </button>
      </div>

      <div className="flex items-center gap-2 mb-6">
        {status === 'active' ? (
          <span className="flex items-center gap-1 text-[10px] font-bold uppercase tracking-wider text-green-600 bg-green-50 px-2 py-1 rounded-full">
            <CheckCircle2 size={12} /> Ativo no WhatsApp
          </span>
        ) : (
          <span className="flex items-center gap-1 text-[10px] font-bold uppercase tracking-wider text-gray-400 bg-gray-50 px-2 py-1 rounded-full">
            <AlertCircle size={12} /> Desativado
          </span>
        )}
      </div>

      <div className="mt-auto flex items-center justify-between gap-4">
        <button 
          onClick={onEdit}
          className="flex-1 flex items-center justify-center gap-2 px-4 py-2 border border-gray-200 rounded-lg text-sm font-semibold text-gray-700 hover:bg-gray-50 transition-colors"
        >
          <Settings2 size={16} />
          Configurar
        </button>
        
        {/* Toggle Switch */}
        <button 
          onClick={onToggle}
          className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors focus:outline-none ${status === 'active' ? 'bg-blue-600' : 'bg-gray-200'}`}
        >
          <span
            className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${status === 'active' ? 'translate-x-6' : 'translate-x-1'}`}
          />
        </button>
      </div>
    </motion.div>
  );
};

export default function Agents() {
  const [agents, setAgents] = useState<Agent[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [editingAgent, setEditingAgent] = useState<Agent | null>(null);
  const [activeTab, setActiveTab] = useState<'profile' | 'company' | 'preview' | 'advanced'>('profile');

  // Form State
  const [formData, setFormData] = useState<Partial<Agent>>({
    nome: '',
    nicho: '',
    prompt_base: '',
    status_ativo: true,
    companyName: '',
    companyAddress: '',
    professionalName: '',
    knowledgeBase: [{ question: '', answer: '' }],
    followUps: [{ delayMinutes: 60, extraPrompt: '' }],
    reminders: [{ mode: 'Tempo antes', hoursBefore: 24, message: '', sendAfterTime: false }]
  });

  const [previewMessages, setPreviewMessages] = useState<{ role: 'user' | 'assistant', content: string }[]>([]);
  const [previewInput, setPreviewInput] = useState('');

  const fetchAgents = async () => {
    try {
      setIsLoading(true);
      const data = await listAgents();
      setAgents(data);
    } catch (error) {
      console.error('Failed to fetch agents:', error);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchAgents();
  }, []);

  const handleToggle = async (agentId: string, currentStatus: boolean) => {
    try {
      await toggleAgentStatus(agentId, currentStatus);
      setAgents(prev => prev.map(a => 
        a.id === agentId ? { ...a, status_ativo: !currentStatus } : a
      ));
    } catch (error) {
      console.error('Failed to toggle status:', error);
    }
  };

  const handleEdit = (agent: Agent) => {
    setEditingAgent(agent);
    setFormData({
      nome: agent.nome || '',
      nicho: agent.nicho || '',
      prompt_base: agent.prompt_base || '',
      status_ativo: agent.status_ativo ?? true,
      companyName: agent.companyName || '',
      companyAddress: agent.companyAddress || '',
      professionalName: agent.professionalName || '',
      knowledgeBase: agent.knowledgeBase?.length ? agent.knowledgeBase : [{ question: '', answer: '' }],
      followUps: agent.followUps?.length ? agent.followUps : [{ delayMinutes: 60, extraPrompt: '' }],
      reminders: agent.reminders?.length ? agent.reminders : [{ mode: 'Tempo antes', hoursBefore: 24, message: '', sendAfterTime: false }]
    });
    setActiveTab('profile');
    setIsModalOpen(true);
  };

  const handleAddNew = () => {
    setEditingAgent(null);
    setFormData({
      nome: '',
      nicho: '',
      prompt_base: '',
      status_ativo: true,
      companyName: '',
      companyAddress: '',
      professionalName: '',
      knowledgeBase: [{ question: '', answer: '' }],
      followUps: [{ delayMinutes: 60, extraPrompt: '' }],
      reminders: [{ mode: 'Tempo antes', hoursBefore: 24, message: '', sendAfterTime: false }]
    });
    setActiveTab('profile');
    setIsModalOpen(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.nome) return;

    try {
      setIsSaving(true);
      if (editingAgent?.id) {
        await updateAgent(editingAgent.id, formData);
      } else {
        await createAgent({
          nome: formData.nome!,
          nicho: formData.nicho || '',
          prompt_base: formData.prompt_base || '',
          status_ativo: formData.status_ativo ?? true,
          companyName: formData.companyName,
          companyAddress: formData.companyAddress,
          professionalName: formData.professionalName,
          knowledgeBase: formData.knowledgeBase,
          followUps: formData.followUps,
          reminders: formData.reminders
        });
      }
      setIsModalOpen(false);
      await fetchAgents();
    } catch (error) {
      console.error('Failed to save agent:', error);
    } finally {
      setIsSaving(false);
    }
  };

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!previewInput.trim()) return;

    const userMsg = previewInput;
    setPreviewInput('');
    setPreviewMessages(prev => [...prev, { role: 'user', content: userMsg }]);

    // Mock AI response for preview
    setTimeout(() => {
      setPreviewMessages(prev => [...prev, { role: 'assistant', content: `Olá! Eu sou o ${formData.nome || 'seu assistente'}. Como posso ajudar você hoje?` }]);
    }, 1000);
  };

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Meus Agentes</h1>
          <p className="text-gray-500 text-sm">Gerencie e configure seus assistentes virtuais inteligentes.</p>
        </div>
        
        <button 
          onClick={handleAddNew}
          className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg text-sm font-semibold hover:bg-blue-700 transition-colors shadow-sm shadow-blue-200"
        >
          <Plus size={18} />
          Novo Agente
        </button>
      </div>

      {isLoading ? (
        <div className="flex flex-col items-center justify-center py-20 text-gray-400">
          <Loader2 size={40} className="animate-spin mb-4 text-blue-500" />
          <p className="font-medium">Carregando seus agentes...</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {agents.map(agent => (
            <AgentCard 
              key={agent.id}
              agent={agent}
              onToggle={() => handleToggle(agent.id!, agent.status_ativo)}
              onEdit={() => handleEdit(agent)}
            />
          ))}

          {/* Empty State / Add New Placeholder */}
          <button 
            onClick={handleAddNew}
            className="border-2 border-dashed border-gray-200 rounded-xl p-6 flex flex-col items-center justify-center text-gray-400 hover:border-blue-300 hover:text-blue-500 hover:bg-blue-50/50 transition-all group min-h-[220px]"
          >
            <div className="w-12 h-12 rounded-full border-2 border-dashed border-current flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
              <Plus size={24} />
            </div>
            <span className="font-medium">Adicionar novo nicho</span>
          </button>
        </div>
      )}

      {/* Modal Novo/Editar Agente */}
      <AnimatePresence>
        {isModalOpen && (
          <div className="fixed inset-0 z-50 flex flex-col bg-gray-50 overflow-y-auto">
            {/* Header */}
            <div className="bg-white border-b border-gray-200 sticky top-0 z-20">
              <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="flex items-center gap-2 text-gray-500 text-sm">
                    <Building2 size={16} />
                    <span>Agentes</span>
                  </div>
                </div>
                <button 
                  onClick={() => setIsModalOpen(false)}
                  className="flex items-center gap-2 px-4 py-2 border border-gray-200 rounded-lg text-sm font-semibold text-gray-700 hover:bg-gray-50 transition-colors"
                >
                  <ArrowLeft size={16} />
                  Voltar para a listagem
                </button>
              </div>
            </div>

            <div className="max-w-7xl mx-auto px-4 py-8 w-full flex-1">
              <div className="mb-8">
                <h1 className="text-3xl font-bold text-gray-900">
                  {editingAgent ? 'Editar Agente' : 'Novo Agente'}
                </h1>
                <p className="text-gray-500">
                  {editingAgent ? 'Atualizar configurações do agente existente' : 'Configure as informações básicas e avançadas do seu novo assistente'}
                </p>
              </div>

              {/* Tabs */}
              <div className="flex items-center gap-8 border-b border-gray-200 mb-8">
                {[
                  { id: 'profile', label: 'Perfil do agente', icon: User },
                  { id: 'company', label: 'Perfil da empresa', icon: Building2 },
                  { id: 'preview', label: 'Pré-visualização', icon: Eye },
                  { id: 'advanced', label: 'Configurações Avançadas', icon: Settings },
                ].map(tab => (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id as any)}
                    className={`flex items-center gap-2 py-4 text-sm font-semibold transition-all relative ${
                      activeTab === tab.id ? 'text-teal-600' : 'text-gray-500 hover:text-gray-700'
                    }`}
                  >
                    <tab.icon size={18} />
                    {tab.label}
                    {activeTab === tab.id && (
                      <motion.div 
                        layoutId="activeTab"
                        className="absolute bottom-0 left-0 right-0 h-0.5 bg-teal-600"
                      />
                    )}
                  </button>
                ))}
              </div>

              {/* Tab Content */}
              <div className="bg-white rounded-2xl border border-gray-200 shadow-sm p-8 min-h-[400px]">
                {activeTab === 'profile' && (
                  <div className="space-y-6 max-w-2xl">
                    <h2 className="text-lg font-bold text-gray-900">Informações básicas</h2>
                    <div>
                      <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Nome do assistente</label>
                      <input 
                        type="text"
                        value={formData.nome}
                        onChange={e => setFormData({...formData, nome: e.target.value})}
                        placeholder="Ex: Natan"
                        className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-teal-500 focus:ring-2 focus:ring-teal-500/20 outline-none transition-all text-sm"
                      />
                    </div>
                  </div>
                )}

                {activeTab === 'company' && (
                  <div className="space-y-8">
                    <div className="space-y-6 max-w-2xl">
                      <h2 className="text-lg font-bold text-gray-900">Informações básicas</h2>
                      <div>
                        <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Nome da empresa</label>
                        <input 
                          type="text"
                          value={formData.companyName}
                          onChange={e => setFormData({...formData, companyName: e.target.value})}
                          placeholder="Ex: Natan de Souza"
                          className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-teal-500 focus:ring-2 focus:ring-teal-500/20 outline-none transition-all text-sm"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Endereço da empresa</label>
                        <input 
                          type="text"
                          value={formData.companyAddress}
                          onChange={e => setFormData({...formData, companyAddress: e.target.value})}
                          placeholder="Ex: Av. Paulista, 1578 - Bela Vista, São Paulo - SP"
                          className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-teal-500 focus:ring-2 focus:ring-teal-500/20 outline-none transition-all text-sm"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Nome do Profissional <span className="text-red-500">*</span></label>
                        <input 
                          type="text"
                          value={formData.professionalName}
                          onChange={e => setFormData({...formData, professionalName: e.target.value})}
                          placeholder="Ex: Dr. João Silva"
                          className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-teal-500 focus:ring-2 focus:ring-teal-500/20 outline-none transition-all text-sm"
                        />
                      </div>
                    </div>

                    <div className="space-y-6">
                      <div>
                        <h2 className="text-lg font-bold text-gray-900">Base de conhecimento</h2>
                        <p className="text-sm text-gray-500 mt-1">Aqui é onde você vai introduzir dados fundamentais para o treinamento do seu Agente...</p>
                      </div>

                      <div className="flex gap-2">
                        <button className="px-4 py-2 bg-teal-600 text-white rounded-lg text-sm font-bold flex items-center gap-2">
                          <MessageSquare size={18} />
                          Perguntas e Respostas
                        </button>
                      </div>

                      <div className="space-y-4">
                        {formData.knowledgeBase?.map((kb, index) => (
                          <div key={index} className="p-6 border border-gray-100 rounded-xl bg-gray-50/50 space-y-4 relative group">
                            <button 
                              onClick={() => {
                                const newKb = [...(formData.knowledgeBase || [])];
                                newKb.splice(index, 1);
                                setFormData({...formData, knowledgeBase: newKb});
                              }}
                              className="absolute top-4 right-4 p-2 text-gray-400 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-opacity"
                            >
                              <Trash2 size={18} />
                            </button>
                            <div>
                              <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Pergunta</label>
                              <input 
                                type="text"
                                value={kb.question}
                                onChange={e => {
                                  const newKb = [...(formData.knowledgeBase || [])];
                                  newKb[index].question = e.target.value;
                                  setFormData({...formData, knowledgeBase: newKb});
                                }}
                                placeholder="Ex: Quanto custa cada produto/serviços da sua empresa?"
                                className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-teal-500 focus:ring-2 focus:ring-teal-500/20 outline-none transition-all text-sm"
                              />
                            </div>
                            <div>
                              <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Resposta <span className="text-red-500">*</span></label>
                              <textarea 
                                rows={3}
                                value={kb.answer}
                                onChange={e => {
                                  const newKb = [...(formData.knowledgeBase || [])];
                                  newKb[index].answer = e.target.value;
                                  setFormData({...formData, knowledgeBase: newKb});
                                }}
                                placeholder="Ex: Consultoria: R$ 200/hora. Desenvolvimento: a partir de R$ 5000."
                                className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-teal-500 focus:ring-2 focus:ring-teal-500/20 outline-none transition-all text-sm resize-none"
                              />
                            </div>
                          </div>
                        ))}
                        <button 
                          onClick={() => setFormData({...formData, knowledgeBase: [...(formData.knowledgeBase || []), { question: '', answer: '' }]})}
                          className="w-full py-3 bg-green-50 text-green-700 border border-dashed border-green-200 rounded-xl font-bold text-sm flex items-center justify-center gap-2 hover:bg-green-100 transition-all"
                        >
                          <Plus size={18} />
                          Adicionar Pergunta
                        </button>
                      </div>
                    </div>
                  </div>
                )}

                {activeTab === 'preview' && (
                  <div className="flex flex-col h-[600px]">
                    <div className="mb-6">
                      <h2 className="text-lg font-bold text-gray-900">Chegou a hora de experimentar o seu agente</h2>
                    </div>

                    <div className="flex-1 border border-gray-200 rounded-2xl overflow-hidden flex flex-col bg-[#f8f9fa] relative">
                      {/* Chat Header */}
                      <div className="p-4 bg-white border-b border-gray-200 flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-full bg-gray-200 flex items-center justify-center text-gray-500 text-xs font-bold">
                            {formData.nome?.[0] || 'A'}
                          </div>
                          <span className="font-bold text-gray-900">{formData.nome || 'Agente'}</span>
                          <span className="flex items-center gap-1 px-2 py-0.5 bg-blue-50 text-blue-600 text-[10px] font-bold rounded uppercase">
                            <MessageSquare size={10} /> Atendimento
                          </span>
                          <span className="flex items-center gap-1 px-2 py-0.5 bg-green-50 text-green-600 text-[10px] font-bold rounded uppercase">
                            <Sparkles size={10} /> Normal
                          </span>
                        </div>
                        <button 
                          onClick={() => setPreviewMessages([])}
                          className="flex items-center gap-1 text-xs text-gray-500 hover:text-gray-700"
                        >
                          <RotateCcw size={14} />
                          Reiniciar conversa
                        </button>
                      </div>

                      {/* Messages */}
                      <div className="flex-1 overflow-y-auto p-6 space-y-4">
                        <div className="flex justify-center">
                          <div className="bg-white border border-gray-200 rounded-full px-4 py-1 flex items-center gap-2 text-[10px] text-gray-500">
                            <AlertCircle size={12} />
                            Bem-vindo ao chat de demonstração. Aqui você pode testar como será a interação...
                          </div>
                        </div>

                        {previewMessages.map((msg, i) => (
                          <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                            <div className={`max-w-[80%] p-3 rounded-2xl text-sm ${
                              msg.role === 'user' ? 'bg-teal-600 text-white' : 'bg-white border border-gray-100 text-gray-800 shadow-sm'
                            }`}>
                              {msg.content}
                            </div>
                          </div>
                        ))}
                      </div>

                      {/* Input */}
                      <div className="p-4 bg-white border-t border-gray-200">
                        <form onSubmit={handleSendMessage} className="flex items-center gap-3">
                          <button type="button" className="p-2 text-gray-400 hover:text-gray-600">
                            <Mic size={20} />
                          </button>
                          <input 
                            type="text"
                            value={previewInput}
                            onChange={e => setPreviewInput(e.target.value)}
                            placeholder="Digite sua mensagem ou grave um áudio..."
                            className="flex-1 bg-gray-50 border border-gray-200 rounded-xl px-4 py-2 text-sm outline-none focus:border-teal-500"
                          />
                          <button 
                            type="submit"
                            className="p-2 bg-teal-500 text-white rounded-lg hover:bg-teal-600 transition-colors"
                          >
                            <Send size={18} />
                          </button>
                        </form>
                      </div>
                    </div>
                  </div>
                )}

                {activeTab === 'advanced' && (
                  <div className="space-y-12">
                    {/* Follow-up */}
                    <div className="space-y-6">
                      <div className="flex items-center gap-2 text-gray-900">
                        <RotateCcw size={20} className="text-gray-400" />
                        <h2 className="text-lg font-bold">Configuração de Follow-up</h2>
                      </div>
                      <p className="text-sm text-gray-500">Configure mensagens automáticas de follow-up para reengajar contatos que não responderam...</p>
                      
                      <div className="space-y-4">
                        {formData.followUps?.map((followUp, index) => (
                          <div key={index} className="p-8 border border-gray-100 rounded-2xl bg-gray-50/30 space-y-6 relative group">
                            <button 
                              onClick={() => {
                                const newFollowUps = [...(formData.followUps || [])];
                                newFollowUps.splice(index, 1);
                                setFormData({...formData, followUps: newFollowUps});
                              }}
                              className="absolute top-4 right-4 p-2 text-gray-400 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-opacity"
                            >
                              <Trash2 size={18} />
                            </button>
                            <div className="max-w-xs">
                              <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Tempo de espera antes do follow-up (minutos)</label>
                              <input 
                                type="number"
                                value={followUp.delayMinutes}
                                onChange={e => {
                                  const newFollowUps = [...(formData.followUps || [])];
                                  newFollowUps[index].delayMinutes = parseInt(e.target.value);
                                  setFormData({...formData, followUps: newFollowUps});
                                }}
                                className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-teal-500 focus:ring-2 focus:ring-teal-500/20 outline-none transition-all text-sm"
                              />
                            </div>
                            <div>
                              <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Conteúdo extra do prompt (opcional)</label>
                              <textarea 
                                rows={3}
                                value={followUp.extraPrompt}
                                onChange={e => {
                                  const newFollowUps = [...(formData.followUps || [])];
                                  newFollowUps[index].extraPrompt = e.target.value;
                                  setFormData({...formData, followUps: newFollowUps});
                                }}
                                placeholder="Instruções adicionais para o agente ao enviar o follow-up..."
                                className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-teal-500 focus:ring-2 focus:ring-teal-500/20 outline-none transition-all text-sm resize-none"
                              />
                            </div>
                          </div>
                        ))}
                        <button 
                          onClick={() => setFormData({...formData, followUps: [...(formData.followUps || []), { delayMinutes: 60, extraPrompt: '' }]})}
                          className="flex items-center gap-2 px-4 py-2 border border-gray-200 rounded-lg text-sm font-bold text-gray-700 hover:bg-gray-50 transition-colors"
                        >
                          <Plus size={16} />
                          Adicionar follow-up
                        </button>
                      </div>
                    </div>

                    {/* Reminders */}
                    <div className="space-y-6">
                      <div className="flex items-center gap-2 text-gray-900">
                        <AlertCircle size={20} className="text-gray-400" />
                        <h2 className="text-lg font-bold">Configuração de Lembretes</h2>
                      </div>
                      <p className="text-sm text-gray-500">Configure lembretes automáticos para agendamentos. O contato receberá uma mensagem antes do horário marcado.</p>

                      <div className="space-y-4">
                        {formData.reminders?.map((reminder, index) => (
                          <div key={index} className="p-8 border border-gray-100 rounded-2xl bg-gray-50/30 space-y-6 relative group">
                            <button 
                              onClick={() => {
                                const newReminders = [...(formData.reminders || [])];
                                newReminders.splice(index, 1);
                                setFormData({...formData, reminders: newReminders});
                              }}
                              className="absolute top-4 right-4 p-2 text-gray-400 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-opacity"
                            >
                              <Trash2 size={18} />
                            </button>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                              <div>
                                <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Modo do lembrete</label>
                                <select 
                                  value={reminder.mode}
                                  onChange={e => {
                                    const newReminders = [...(formData.reminders || [])];
                                    newReminders[index].mode = e.target.value;
                                    setFormData({...formData, reminders: newReminders});
                                  }}
                                  className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-teal-500 focus:ring-2 focus:ring-teal-500/20 outline-none transition-all text-sm bg-white"
                                >
                                  <option>Tempo antes</option>
                                  <option>No horário</option>
                                </select>
                              </div>
                              <div>
                                <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Horas antes do agendamento</label>
                                <input 
                                  type="number"
                                  value={reminder.hoursBefore}
                                  onChange={e => {
                                    const newReminders = [...(formData.reminders || [])];
                                    newReminders[index].hoursBefore = parseInt(e.target.value);
                                    setFormData({...formData, reminders: newReminders});
                                  }}
                                  className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-teal-500 focus:ring-2 focus:ring-teal-500/20 outline-none transition-all text-sm"
                                />
                              </div>
                            </div>
                            <div>
                              <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Mensagem do lembrete</label>
                              <textarea 
                                rows={4}
                                value={reminder.message}
                                onChange={e => {
                                  const newReminders = [...(formData.reminders || [])];
                                  newReminders[index].message = e.target.value;
                                  setFormData({...formData, reminders: newReminders});
                                }}
                                placeholder="Olá! Você tem um agendamento marcado para..."
                                className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-teal-500 focus:ring-2 focus:ring-teal-500/20 outline-none transition-all text-sm resize-none"
                              />
                              <div className="mt-2 flex flex-wrap items-center gap-2">
                                <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Inserir variável:</span>
                                {[
                                  { label: 'Data', value: '{appointment_date}' },
                                  { label: 'Horário', value: '{appointment_time}' },
                                  { label: 'Local', value: '{appointment_location}' },
                                  { label: 'Cliente', value: '{client_name}' },
                                  { label: 'Primeiro nome', value: '{client_first_name}' },
                                  { label: 'Profissional', value: '{professional_name}' }
                                ].map(tag => (
                                  <button 
                                    key={tag.label} 
                                    type="button"
                                    onClick={() => {
                                      const newReminders = [...(formData.reminders || [])];
                                      const currentMsg = newReminders[index].message || '';
                                      newReminders[index].message = currentMsg + tag.value;
                                      setFormData({...formData, reminders: newReminders});
                                    }}
                                    className="px-2 py-1 bg-green-100 text-green-700 text-[10px] font-bold rounded hover:bg-green-200 transition-colors"
                                  >
                                    {tag.label}
                                  </button>
                                ))}
                              </div>
                            </div>
                            <div className="flex items-center gap-3">
                              <button 
                                onClick={() => {
                                  const newReminders = [...(formData.reminders || [])];
                                  newReminders[index].sendAfterTime = !newReminders[index].sendAfterTime;
                                  setFormData({...formData, reminders: newReminders});
                                }}
                                className={`relative inline-flex h-5 w-9 items-center rounded-full transition-colors focus:outline-none ${reminder.sendAfterTime ? 'bg-teal-600' : 'bg-gray-200'}`}
                              >
                                <span className={`inline-block h-3 w-3 transform rounded-full bg-white transition-transform ${reminder.sendAfterTime ? 'translate-x-5' : 'translate-x-1'}`} />
                              </button>
                              <span className="text-xs text-gray-500">Enviar lembrete mesmo após o horário</span>
                            </div>
                          </div>
                        ))}
                        <button 
                          onClick={() => setFormData({...formData, reminders: [...(formData.reminders || []), { mode: 'Tempo antes', hoursBefore: 24, message: '', sendAfterTime: false }]})}
                          className="flex items-center gap-2 px-4 py-2 border border-gray-200 rounded-lg text-sm font-bold text-gray-700 hover:bg-gray-50 transition-colors"
                        >
                          <Plus size={16} />
                          Adicionar lembrete
                        </button>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Footer Actions */}
              <div className="mt-8 pt-8 border-t border-gray-200 flex items-center justify-between">
                <button 
                  onClick={() => setIsModalOpen(false)}
                  className="px-6 py-2 border border-gray-200 rounded-lg text-sm font-bold text-gray-600 hover:bg-gray-50 transition-colors"
                >
                  Cancelar
                </button>
                <button 
                  onClick={handleSave}
                  disabled={isSaving}
                  className="px-8 py-3 bg-teal-600 text-white rounded-lg text-sm font-bold hover:bg-teal-700 transition-all shadow-lg shadow-teal-200 flex items-center gap-2 disabled:opacity-70"
                >
                  {isSaving ? <Loader2 size={18} className="animate-spin" /> : <Save size={18} />}
                  {editingAgent ? 'Atualizar agente' : 'Criar agente'}
                </button>
              </div>
            </div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
