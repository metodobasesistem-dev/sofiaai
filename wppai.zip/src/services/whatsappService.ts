import { auth, db } from '../firebase';
import { doc, onSnapshot } from 'firebase/firestore';

const API_BASE_URL = '/api/sessions';

export interface WhatsAppStatusResponse {
  status: 'connected' | 'disconnected' | 'waiting';
  qr?: string;
}

/**
 * Initiate a WhatsApp connection (get QR code).
 */
export const connectWhatsApp = async (): Promise<{ success: boolean; qr?: string }> => {
  const user = auth.currentUser;
  if (!user) throw new Error('User not authenticated');

  const response = await fetch(`${API_BASE_URL}/create`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({ userId: user.uid })
  });

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({}));
    throw new Error(errorData.error || 'Failed to initiate WhatsApp connection');
  }

  return response.json();
};

/**
 * Listen to WhatsApp session status in real-time.
 */
export const listenToWhatsAppSession = (userId: string, callback: (data: WhatsAppStatusResponse) => void) => {
  const sessionDoc = doc(db, 'sessions', userId);
  return onSnapshot(sessionDoc, (snapshot) => {
    if (snapshot.exists()) {
      callback(snapshot.data() as WhatsAppStatusResponse);
    } else {
      callback({ status: 'disconnected' });
    }
  }, (error) => {
    console.error('Error listening to WhatsApp session:', error);
  });
};

/**
 * Get the current WhatsApp connection status via API.
 */
export const getWhatsAppStatus = async (): Promise<{ status: string }> => {
  const user = auth.currentUser;
  if (!user) throw new Error('User not authenticated');

  const response = await fetch(`${API_BASE_URL}/status/${user.uid}`);

  if (!response.ok) {
    throw new Error('Failed to fetch WhatsApp status');
  }

  return response.json();
};

/**
 * Send a WhatsApp message via the backend API.
 */
export const sendMessage = async (to: string, message: string) => {
  const user = auth.currentUser;
  if (!user) throw new Error('User not authenticated');

  const response = await fetch('/api/messages/send', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      userId: user.uid,
      to,
      message,
    }),
  });

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({}));
    throw new Error(errorData.error || 'Failed to send message');
  }

  return response.json();
};
