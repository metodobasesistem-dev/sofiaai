import { 
  collection, 
  addDoc, 
  query, 
  where, 
  getDocs, 
  updateDoc, 
  doc, 
  getDoc,
  setDoc,
  deleteDoc,
  serverTimestamp,
  Timestamp,
  getDocFromServer
} from 'firebase/firestore';
import { db, auth } from '../firebase';

// Error Handling Spec for Firestore Operations
export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId: string | undefined;
    email: string | null | undefined;
    emailVerified: boolean | undefined;
    isAnonymous: boolean | undefined;
    tenantId: string | null | undefined;
    providerInfo: {
      providerId: string;
      displayName: string | null;
      email: string | null;
      photoUrl: string | null;
    }[];
  }
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo: auth.currentUser?.providerData.map(provider => ({
        providerId: provider.providerId,
        displayName: provider.displayName,
        email: provider.email,
        photoUrl: provider.photoURL
      })) || []
    },
    operationType,
    path
  }
  console.error('Firestore Error: ', JSON.stringify(errInfo, null, 2));
  throw new Error(JSON.stringify(errInfo));
}

/**
 * Test the connection to Firestore.
 */
export async function testConnection() {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
  } catch (error) {
    if(error instanceof Error && error.message.includes('the client is offline')) {
      console.error("Please check your Firebase configuration. ");
    }
    // Skip logging for other errors, as this is simply a connection test.
  }
}

// Types based on blueprint
export interface Agent {
  id?: string;
  userId: string;
  nome: string;
  nicho: string;
  prompt_base: string;
  status_ativo: boolean;
  companyName?: string;
  companyAddress?: string;
  professionalName?: string;
  knowledgeBase?: {
    question: string;
    answer: string;
  }[];
  followUps?: {
    delayMinutes: number;
    extraPrompt: string;
  }[];
  reminders?: {
    mode: string;
    hoursBefore: number;
    message: string;
    sendAfterTime: boolean;
  }[];
}

export interface Contact {
  id?: string;
  userId: string;
  nome: string;
  telefone: string;
  status_funil: 'Lead' | 'Qualificado';
  data_criacao: Timestamp | Date | string;
}

export interface UserProfile {
  id?: string;
  email: string;
  name?: string;
  photoURL?: string;
  role: 'admin' | 'client';
  whatsapp_status: 'connected' | 'disconnected' | 'connecting';
  whatsapp_instance_id?: string;
  createdAt?: any;
  updatedAt?: any;
  nome_completo?: string;
  nome_empresa?: string;
  whatsapp_organizacao?: string;
  plano?: string;
}

export interface Channel {
  id?: string;
  userId: string;
  nome: string;
  agentId: string;
  tipo: 'whatsapp' | 'chat' | 'telegram';
  status: 'ativo' | 'inativo';
}

/**
 * Create a new AI Agent for the current user.
 */
export const createAgent = async (agentData: Omit<Agent, 'id' | 'userId'>) => {
  const user = auth.currentUser;
  if (!user) throw new Error('User not authenticated');

  const agentsCollection = collection(db, 'agents');
  const newAgent = {
    ...agentData,
    userId: user.uid,
  };

  try {
    const docRef = await addDoc(agentsCollection, newAgent);
    return { id: docRef.id, ...newAgent };
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, 'agents');
  }
};

/**
 * Update an existing AI Agent.
 */
export const updateAgent = async (agentId: string, agentData: Partial<Agent>) => {
  const user = auth.currentUser;
  if (!user) throw new Error('User not authenticated');

  const agentDocRef = doc(db, 'agents', agentId);

  try {
    await updateDoc(agentDocRef, agentData);
    return { success: true };
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, `agents/${agentId}`);
  }
};

/**
 * List contacts for a specific user (multi-tenant check).
 */
export const listContacts = async () => {
  const user = auth.currentUser;
  if (!user) throw new Error('User not authenticated');

  const contactsCollection = collection(db, 'contacts');
  const q = query(contactsCollection, where('userId', '==', user.uid));

  try {
    const querySnapshot = await getDocs(q);
    return querySnapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data()
    })) as Contact[];
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, 'contacts');
  }
};

/**
 * Create a new contact manually.
 */
export const createContact = async (contactData: Omit<Contact, 'id' | 'userId' | 'data_criacao'>) => {
  const user = auth.currentUser;
  if (!user) throw new Error('User not authenticated');

  const contactsCollection = collection(db, 'contacts');
  const newContact = {
    ...contactData,
    userId: user.uid,
    data_criacao: serverTimestamp(),
  };

  try {
    const docRef = await addDoc(contactsCollection, newContact);
    return { id: docRef.id, ...newContact };
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, 'contacts');
  }
};

/**
 * List agents for a specific user (multi-tenant check).
 */
export const listAgents = async () => {
  const user = auth.currentUser;
  if (!user) throw new Error('User not authenticated');

  const agentsCollection = collection(db, 'agents');
  const q = query(agentsCollection, where('userId', '==', user.uid));

  try {
    const querySnapshot = await getDocs(q);
    return querySnapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data()
    })) as Agent[];
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, 'agents');
  }
};

/**
 * Get the current user's profile.
 */
export const getUserProfile = async () => {
  const user = auth.currentUser;
  if (!user) throw new Error('User not authenticated');

  const userDocRef = doc(db, 'users', user.uid);

  try {
    const userDoc = await getDoc(userDocRef);
    if (userDoc.exists()) {
      const data = userDoc.data();
      // Se o documento existe mas falta o email (criado pelo servidor sem email), atualiza
      if (!data.email || !data.whatsapp_status) {
        const updates: any = {};
        if (!data.email) updates.email = user.email || '';
        if (!data.whatsapp_status) updates.whatsapp_status = 'disconnected';
        if (!data.role) updates.role = 'client';
        if (!data.name) updates.name = user.displayName || '';
        if (!data.photoURL) updates.photoURL = user.photoURL || '';
        
        if (Object.keys(updates).length > 0) {
          await setDoc(userDocRef, updates, { merge: true });
          const updatedDoc = await getDoc(userDocRef);
          return { id: updatedDoc.id, ...updatedDoc.data() } as UserProfile;
        }
      }
      return { id: userDoc.id, ...data } as UserProfile;
    } else {
      // Create profile if it doesn't exist
      const newProfile: Omit<UserProfile, 'id'> = {
        email: user.email || '',
        name: user.displayName || '',
        photoURL: user.photoURL || '',
        role: 'client',
        whatsapp_status: 'disconnected',
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      };
      await setDoc(userDocRef, newProfile);
      return { id: user.uid, ...newProfile } as UserProfile;
    }
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, `users/${user.uid}`);
  }
};

/**
 * Update the current user's profile.
 */
export const updateUserProfile = async (profileData: Partial<UserProfile>) => {
  const user = auth.currentUser;
  if (!user) throw new Error('User not authenticated');

  const userDocRef = doc(db, 'users', user.uid);

  try {
    await setDoc(userDocRef, { ...profileData, updatedAt: serverTimestamp() }, { merge: true });
    return { success: true };
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `users/${user.uid}`);
  }
};

/**
 * Toggle agent active status.
 */
export const toggleAgentStatus = async (agentId: string, currentStatus: boolean) => {
  const user = auth.currentUser;
  if (!user) throw new Error('User not authenticated');

  const agentDocRef = doc(db, 'agents', agentId);

  try {
    await updateDoc(agentDocRef, { status_ativo: !currentStatus });
    return { success: true };
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, `agents/${agentId}`);
  }
};

/**
 * Update the WhatsApp connection status for the current user profile.
 */
export const updateWhatsAppStatus = async (status: 'connected' | 'disconnected' | 'connecting') => {
  const user = auth.currentUser;
  if (!user) throw new Error('User not authenticated');

  const userDocRef = doc(db, 'users', user.uid);

  try {
    await setDoc(userDocRef, { 
      whatsapp_status: status,
      updatedAt: serverTimestamp()
    }, { merge: true });
    return { success: true };
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `users/${user.uid}`);
  }
};

/**
 * List channels for a specific user.
 */
export const listChannels = async () => {
  const user = auth.currentUser;
  if (!user) throw new Error('User not authenticated');

  const channelsCollection = collection(db, 'channels');
  const q = query(channelsCollection, where('userId', '==', user.uid));

  try {
    const querySnapshot = await getDocs(q);
    return querySnapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data()
    })) as Channel[];
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, 'channels');
  }
};

/**
 * Create a new channel.
 */
export const createChannel = async (channelData: Omit<Channel, 'id' | 'userId'>) => {
  const user = auth.currentUser;
  if (!user) throw new Error('User not authenticated');

  const channelsCollection = collection(db, 'channels');
  const newChannel = {
    ...channelData,
    userId: user.uid,
  };

  try {
    const docRef = await addDoc(channelsCollection, newChannel);
    return { id: docRef.id, ...newChannel };
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, 'channels');
  }
};

/**
 * Delete a channel.
 */
export const deleteChannel = async (channelId: string) => {
  const user = auth.currentUser;
  if (!user) throw new Error('User not authenticated');

  const channelDocRef = doc(db, 'channels', channelId);

  try {
    await deleteDoc(channelDocRef);
    return { success: true };
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, `channels/${channelId}`);
  }
};
