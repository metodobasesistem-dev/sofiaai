import { useState, useEffect } from 'react';
import Layout from './components/Layout';
import Dashboard from './components/Dashboard';
import Agents from './components/Agents';
import Inbox from './components/Inbox';
import Contacts from './components/Contacts';
import Schedules from './components/Schedules';
import Availability from './components/Availability';
import Integrations from './components/Integrations';
import Settings from './components/Settings';
import Login from './components/Login';
import { auth } from './firebase';
import { onAuthStateChanged, User } from 'firebase/auth';
import { Loader2 } from 'lucide-react';
import { Toaster } from 'sonner';

export default function App() {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [settingsSubTab, setSettingsSubTab] = useState('account');
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Check for JID in URL to auto-select Inbox
    const params = new URLSearchParams(window.location.search);
    if (params.has('jid')) {
      setActiveTab('inbox');
    }

    const unsubscribe = onAuthStateChanged(auth, (user) => {
      setUser(user);
      setLoading(false);
    });
    return () => unsubscribe();
  }, []);

  const handleTabChange = (tab: string, subTab?: string) => {
    setActiveTab(tab);
    if (tab === 'settings' && subTab) {
      setSettingsSubTab(subTab);
    } else if (tab === 'settings' && !subTab) {
      setSettingsSubTab('account');
    }
  };

  if (loading) {
    return (
      <div className="h-screen w-screen flex flex-col items-center justify-center bg-gray-50 text-blue-600">
        <Loader2 size={48} className="animate-spin mb-4" />
        <p className="font-bold text-lg">Carregando...</p>
      </div>
    );
  }

  if (!user) {
    return <Login />;
  }

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard':
        return <Dashboard onTabChange={handleTabChange} />;
      case 'agents':
        return <Agents />;
      case 'inbox':
        return <Inbox />;
      case 'contacts':
        return <Contacts onTabChange={handleTabChange} />;
      case 'schedule':
        return <Schedules />;
      case 'availability':
        return <Availability />;
      case 'integrations':
        return <Integrations />;
      case 'settings':
        return <Settings initialSubTab={settingsSubTab} />;
      default:
        return (
          <div className="h-[60vh] flex flex-col items-center justify-center text-gray-400">
            <h2 className="text-xl font-semibold mb-2">Em desenvolvimento</h2>
            <p>A página "{activeTab}" estará disponível em breve.</p>
          </div>
        );
    }
  };

  return (
    <Layout activeTab={activeTab} onTabChange={handleTabChange}>
      {renderContent()}
      <Toaster position="top-right" richColors />
    </Layout>
  );
}
