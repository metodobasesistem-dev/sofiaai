import axios from 'axios';
import { WhatsAppProvider, CanonicalInboundEvent } from './whatsappProvider.js';

/**
 * UAZAPI Implementation
 * Adapter for UAZAPI (WhatsApp API).
 */
export class UAZAPIProvider implements WhatsAppProvider {
  name = 'uazapi';
  private baseUrl: string;
  private apiKey: string;
  private webhookSecret?: string;

  constructor(config: { baseUrl: string; apiKey: string; webhookSecret?: string }) {
    this.baseUrl = config.baseUrl;
    this.apiKey = config.apiKey;
    this.webhookSecret = config.webhookSecret;
  }

  /**
   * Verifies the incoming webhook request.
   * UAZAPI usually sends a secret in the headers or as a query param.
   */
  verifyWebhook(req: any): boolean {
    if (!this.webhookSecret) return true; // Skip if no secret configured
    
    const secret = req.headers['x-uazapi-secret'] || req.query.secret;
    return secret === this.webhookSecret;
  }

  /**
   * Parses the UAZAPI payload into canonical events.
   * Payload structure assumed from common UAZAPI patterns:
   * {
   *   "instance": "instance-id",
   *   "data": {
   *     "key": { "remoteJid": "...", "id": "..." },
   *     "message": { "conversation": "..." },
   *     "pushName": "...",
   *     "messageTimestamp": 123456789
   *   }
   * }
   */
  async parseInbound(req: any): Promise<CanonicalInboundEvent[]> {
    const body = req.body;
    const instanceId = body.instance || body.instanceId;
    const data = body.data;

    if (!instanceId || !data || !data.key) {
      return [];
    }

    const remoteJid = data.key.remoteJid;
    if (!remoteJid || remoteJid.includes('@g.us')) {
      // Ignore groups for now
      return [];
    }

    const message = data.message;
    const text = message?.conversation || message?.extendedTextMessage?.text || message?.imageMessage?.caption;
    
    if (!text && !message?.imageMessage && !message?.audioMessage && !message?.documentMessage) {
      return [];
    }

    const event: CanonicalInboundEvent = {
      uid: instanceId.replace('wppai-', ''), // Assuming instanceId contains the UID
      channel: 'whatsapp',
      provider: this.name,
      from: remoteJid.split('@')[0],
      to: body.sender?.split('@')[0], // If available
      contactName: data.pushName,
      messageId: data.key.id,
      timestamp: data.messageTimestamp ? data.messageTimestamp * 1000 : Date.now(),
      type: this.getMessageType(message),
      text: text,
      mediaUrl: this.getMediaUrl(message),
      raw: body
    };

    return [event];
  }

  private getMessageType(message: any): CanonicalInboundEvent['type'] {
    if (message?.conversation || message?.extendedTextMessage) return 'text';
    if (message?.imageMessage) return 'image';
    if (message?.audioMessage) return 'audio';
    if (message?.documentMessage) return 'document';
    return 'unknown';
  }

  private getMediaUrl(message: any): string | undefined {
    // Media handling usually requires downloading from the provider
    // For now, we'll just return undefined or a placeholder if available
    return undefined;
  }

  /**
   * Sends a text message via UAZAPI.
   */
  async sendText(params: { uid: string; to: string; text: string; instanceId?: string }): Promise<{ providerMessageId?: string }> {
    const instanceId = params.instanceId || `wppai-${params.uid.substring(0, 8)}`;
    
    try {
      const response = await axios.post(
        `${this.baseUrl}/message/sendText/${instanceId}`,
        {
          number: params.to,
          text: params.text,
          delay: 1200
        },
        {
          headers: {
            'apikey': this.apiKey,
            'Content-Type': 'application/json'
          }
        }
      );

      return { providerMessageId: response.data?.key?.id };
    } catch (error: any) {
      console.error('UAZAPI sendText error:', error.response?.data || error.message);
      throw new Error(`UAZAPI failed to send message: ${error.message}`);
    }
  }

  /**
   * Gets connection status.
   */
  async getConnectionStatus(params: { uid: string; instanceId?: string }): Promise<{ status: 'connected' | 'disconnected' | 'connecting'; qrCode?: string }> {
    const instanceId = params.instanceId || `wppai-${params.uid.substring(0, 8)}`;
    
    try {
      const response = await axios.get(`${this.baseUrl}/instance/connectionStatus/${instanceId}`, {
        headers: { 'apikey': this.apiKey }
      });

      const state = response.data?.instance?.state; // 'open', 'close', 'connecting'
      
      return {
        status: state === 'open' ? 'connected' : state === 'connecting' ? 'connecting' : 'disconnected'
      };
    } catch (error: any) {
      if (error.response?.status === 404) {
        return { status: 'disconnected' };
      }
      throw error;
    }
  }

  /**
   * Connects/Generates QR Code.
   */
  async connect(params: { uid: string; instanceId?: string }): Promise<{ qrCode?: string; status: 'connected' | 'disconnected' | 'connecting' }> {
    const instanceId = params.instanceId || `wppai-${params.uid.substring(0, 8)}`;
    
    try {
      // 1. Check current status
      let currentState = 'close';
      try {
        const statusRes = await axios.get(`${this.baseUrl}/instance/connectionStatus/${instanceId}`, {
          headers: { 'apikey': this.apiKey }
        });
        currentState = statusRes.data?.instance?.state || 'close';
      } catch (error: any) {
        if (error.response?.status === 404) {
          // Create instance if doesn't exist
          await axios.post(`${this.baseUrl}/instance/create`, {
            instanceName: instanceId,
            token: params.uid,
            qrcode: true
          }, {
            headers: { 'apikey': this.apiKey }
          });
        } else {
          throw error;
        }
      }

      // If already open, return connected
      if (currentState === 'open') {
        return { status: 'connected' };
      }

      // 2. Get QR Code
      const qrResponse = await axios.get(`${this.baseUrl}/instance/connect/${instanceId}`, {
        headers: { 'apikey': this.apiKey }
      });

      const qrCode = qrResponse.data?.base64 || qrResponse.data?.code || qrResponse.data?.qrcode;
      
      if (!qrCode) {
        // If no QR code but status is open, return connected
        if (qrResponse.data?.instance?.state === 'open') {
          return { status: 'connected' };
        }
        console.error('UAZAPI: No QR Code found in response', qrResponse.data);
        throw new Error('Não foi possível obter o QR Code do provedor. Verifique se a instância está pronta.');
      }

      return {
        qrCode,
        status: 'connecting'
      };
    } catch (error: any) {
      const errorMsg = error.response?.data?.message || error.response?.data?.error || error.message;
      console.error('UAZAPI connect error:', errorMsg);
      throw new Error(`Erro no Provedor WhatsApp: ${errorMsg}`);
    }
  }

  /**
   * Disconnects instance.
   */
  async disconnect(params: { uid: string; instanceId?: string }): Promise<{ success: boolean }> {
    const instanceId = params.instanceId || `wppai-${params.uid.substring(0, 8)}`;
    
    try {
      // Try logout first
      try {
        await axios.delete(`${this.baseUrl}/instance/logout/${instanceId}`, {
          headers: { 'apikey': this.apiKey }
        });
      } catch (e) {
        console.warn('UAZAPI logout failed (might already be logged out):', e.message);
      }

      // Then delete instance
      await axios.delete(`${this.baseUrl}/instance/delete/${instanceId}`, {
        headers: { 'apikey': this.apiKey }
      });
      
      return { success: true };
    } catch (error: any) {
      console.error('UAZAPI disconnect error:', error.response?.data || error.message);
      // If delete fails, it might be because it's already deleted
      if (error.response?.status === 404) {
        return { success: true };
      }
      return { success: false };
    }
  }

  /**
   * Configures the webhook URL for the instance.
   */
  async setWebhook(params: { uid: string; instanceId?: string; url: string }): Promise<{ success: boolean }> {
    const instanceId = params.instanceId || `wppai-${params.uid.substring(0, 8)}`;
    
    try {
      await axios.post(`${this.baseUrl}/instance/setWebhook/${instanceId}`, {
        url: params.url,
        enabled: true
      }, {
        headers: { 
          'apikey': this.apiKey,
          'Content-Type': 'application/json'
        }
      });
      return { success: true };
    } catch (error: any) {
      console.error('UAZAPI setWebhook error:', error.response?.data || error.message);
      return { success: false };
    }
  }
}
