/**
 * Canonical Inbound Event
 * Normalizes payloads from different WhatsApp providers into a single format.
 */
export type CanonicalInboundEvent = {
  uid: string;
  channel: 'whatsapp';
  provider: string;
  from: string;         // Customer's phone number (E.164 or equivalent ID)
  to?: string;          // Connected phone number (if available)
  contactName?: string;
  messageId: string;
  timestamp: number;
  type: 'text' | 'image' | 'audio' | 'document' | 'unknown';
  text?: string;
  mediaUrl?: string;
  raw?: any;            // Optional for debug
};

/**
 * WhatsApp Provider Interface
 * All WhatsApp integrations must implement this interface.
 */
export interface WhatsAppProvider {
  name: string;

  /**
   * Validates the incoming webhook request (e.g., checking signatures).
   */
  verifyWebhook(req: any): boolean;

  /**
   * Parses the provider-specific payload into one or more canonical events.
   */
  parseInbound(req: any): Promise<CanonicalInboundEvent[]>;

  /**
   * Sends a text message.
   */
  sendText(params: { 
    uid: string; 
    to: string; 
    text: string; 
    instanceId?: string; // For providers that use instance-based routing
  }): Promise<{ providerMessageId?: string }>;

  /**
   * Gets the current connection status for a given user/instance.
   */
  getConnectionStatus(params: { uid: string; instanceId?: string }): Promise<{ 
    status: 'connected' | 'disconnected' | 'connecting';
    qrCode?: string;
  }>;

  /**
   * Initiates a connection (e.g., generates a QR code).
   */
  connect(params: { uid: string; instanceId?: string }): Promise<{ 
    qrCode?: string;
    status: 'connected' | 'disconnected' | 'connecting';
  }>;

  /**
   * Disconnects the instance.
   */
  disconnect(params: { uid: string; instanceId?: string }): Promise<{ success: boolean }>;

  /**
   * Configures the webhook URL for the provider.
   */
  setWebhook(params: { uid: string; instanceId?: string; url: string }): Promise<{ success: boolean }>;
}
