import { WhatsAppProvider } from './whatsappProvider.js';
import { UAZAPIProvider } from './uazapiProvider.js';
import { MetaCloudProvider } from './metaCloudProvider.js';

/**
 * Provider Factory
 * Returns the configured WhatsApp provider based on environment variables.
 */
export function getWhatsAppProvider(): WhatsAppProvider {
  const providerType = process.env.WHATSAPP_PROVIDER || 'uazapi';

  switch (providerType) {
    case 'uazapi':
      const baseUrl = (process.env.UAZAPI_BASE_URL || '').replace(/\/$/, '');
      return new UAZAPIProvider({
        baseUrl,
        apiKey: process.env.UAZAPI_API_KEY || '',
        webhookSecret: process.env.UAZAPI_WEBHOOK_SECRET
      });
    
    case 'meta-cloud':
      return new MetaCloudProvider({
        accessToken: process.env.META_ACCESS_TOKEN || '',
        phoneNumberId: process.env.META_PHONE_NUMBER_ID || '',
        businessAccountId: process.env.META_BUSINESS_ACCOUNT_ID || ''
      });

    default:
      throw new Error(`Unsupported WhatsApp provider: ${providerType}`);
  }
}
